var __esm = (fn, res) => function __init() {
  return fn && (res = (0, fn[Object.keys(fn)[0]])(fn = 0)), res;
};
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[Object.keys(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// <define:__EXTERNAL_LINK_ICON_LOCALES__>
var init_define_EXTERNAL_LINK_ICON_LOCALES = __esm({
  "<define:__EXTERNAL_LINK_ICON_LOCALES__>"() {
  }
});

// <define:__MZ_ZOOM_OPTIONS__>
var init_define_MZ_ZOOM_OPTIONS = __esm({
  "<define:__MZ_ZOOM_OPTIONS__>"() {
  }
});

// <define:__SEARCH_HOT_KEYS__>
var init_define_SEARCH_HOT_KEYS = __esm({
  "<define:__SEARCH_HOT_KEYS__>"() {
  }
});

// <define:__SEARCH_LOCALES__>
var init_define_SEARCH_LOCALES = __esm({
  "<define:__SEARCH_LOCALES__>"() {
  }
});

export {
  __commonJS,
  init_define_EXTERNAL_LINK_ICON_LOCALES,
  init_define_MZ_ZOOM_OPTIONS,
  init_define_SEARCH_HOT_KEYS,
  init_define_SEARCH_LOCALES
};
//# sourceMappingURL=chunk-GY7CAVZH.js.map
