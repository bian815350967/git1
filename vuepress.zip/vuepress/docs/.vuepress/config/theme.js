module.exports = {
  // startYear: "2022",
  // 最后更新时间
  // lastUpdated: "最近更新时间",
};
