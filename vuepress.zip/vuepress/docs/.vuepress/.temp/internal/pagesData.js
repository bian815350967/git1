export const pagesData = {
  // path: /
  "v-8daa1a0e": () => import(/* webpackChunkName: "v-8daa1a0e" */"C:/Users/x90603/mvue/vuepressdome/docs/.vuepress/.temp/pages/index.html.js").then(({ data }) => data),
  // path: /emoji/em.html
  "v-2f7343e2": () => import(/* webpackChunkName: "v-2f7343e2" */"C:/Users/x90603/mvue/vuepressdome/docs/.vuepress/.temp/pages/emoji/em.html.js").then(({ data }) => data),
  // path: /emoji/
  "v-7c2a9ce2": () => import(/* webpackChunkName: "v-7c2a9ce2" */"C:/Users/x90603/mvue/vuepressdome/docs/.vuepress/.temp/pages/emoji/index.html.js").then(({ data }) => data),
  // path: /guide/add.html
  "v-8e00dc78": () => import(/* webpackChunkName: "v-8e00dc78" */"C:/Users/x90603/mvue/vuepressdome/docs/.vuepress/.temp/pages/guide/add.html.js").then(({ data }) => data),
  // path: /guide/function.html
  "v-477f1a95": () => import(/* webpackChunkName: "v-477f1a95" */"C:/Users/x90603/mvue/vuepressdome/docs/.vuepress/.temp/pages/guide/function.html.js").then(({ data }) => data),
  // path: /guide/
  "v-fffb8e28": () => import(/* webpackChunkName: "v-fffb8e28" */"C:/Users/x90603/mvue/vuepressdome/docs/.vuepress/.temp/pages/guide/index.html.js").then(({ data }) => data),
  // path: /404.html
  "v-3706649a": () => import(/* webpackChunkName: "v-3706649a" */"C:/Users/x90603/mvue/vuepressdome/docs/.vuepress/.temp/pages/404.html.js").then(({ data }) => data),
}
