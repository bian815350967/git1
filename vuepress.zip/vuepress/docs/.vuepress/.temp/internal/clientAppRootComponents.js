import clientAppRootComponent0 from 'C:/Users/x90603/mvue/vuepressdome/node_modules/@vuepress/plugin-back-to-top/lib/client/components/BackToTop.js'

export const clientAppRootComponents = [
  clientAppRootComponent0,
]
