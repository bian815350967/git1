<template><p>dsgsagds
sdgdsg
dsgdsagsa</p>
<div class="custom-container tip"><p class="custom-container-title">提示</p>
<p>this is a tip</p>
</div>
<div class="custom-container warning"><p class="custom-container-title">注意</p>
<p>this is a tip</p>
</div>
<div class="custom-container danger"><p class="custom-container-title">警告</p>
<p>this is a tip</p>
</div>
</template>
