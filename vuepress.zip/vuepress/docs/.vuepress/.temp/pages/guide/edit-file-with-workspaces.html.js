export const data = {
  "key": "v-78adc8a4",
  "path": "/guide/edit-file-with-workspaces.html",
  "title": "Chrome 直接编辑文件",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "添加工作区",
      "slug": "添加工作区",
      "children": []
    },
    {
      "level": 2,
      "title": "编辑内容",
      "slug": "编辑内容",
      "children": []
    },
    {
      "level": 2,
      "title": "更多编辑",
      "slug": "更多编辑",
      "children": []
    }
  ],
  "git": {},
  "filePathRelative": "guide/edit-file-with-workspaces.md"
}

if (import.meta.webpackHot) {
  import.meta.webpackHot.accept()
  if (__VUE_HMR_RUNTIME__.updatePageData) {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  }
}

if (import.meta.hot) {
  import.meta.hot.accept(({ data }) => {
    __VUE_HMR_RUNTIME__.updatePageData(data)
  })
}
