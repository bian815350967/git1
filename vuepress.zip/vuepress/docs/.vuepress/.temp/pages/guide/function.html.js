export const data = {
  "key": "v-477f1a95",
  "path": "/guide/function.html",
  "title": "方法",
  "lang": "en-US",
  "frontmatter": {
    "title": "方法",
    "date": "2022-01-04T00:00:00.000Z"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "1.秒转时分秒",
      "slug": "_1-秒转时分秒",
      "children": []
    },
    {
      "level": 2,
      "title": "2.补零",
      "slug": "_2-补零",
      "children": []
    },
    {
      "level": 2,
      "title": "3.获取日期格式化",
      "slug": "_3-获取日期格式化",
      "children": []
    },
    {
      "level": 2,
      "title": "4.下载文件进度条",
      "slug": "_4-下载文件进度条",
      "children": []
    },
    {
      "level": 2,
      "title": "5.数组转化",
      "slug": "_5-数组转化",
      "children": []
    }
  ],
  "git": {},
  "filePathRelative": "guide/function.md"
}
