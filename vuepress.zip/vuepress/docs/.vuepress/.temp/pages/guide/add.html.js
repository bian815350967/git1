export const data = {
  "key": "v-8e00dc78",
  "path": "/guide/add.html",
  "title": "vuepress 打包",
  "lang": "en-US",
  "frontmatter": {
    "title": "vuepress 打包",
    "date": "2022-01-04T00:00:00.000Z"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 3,
      "title": "打包背景",
      "slug": "打包背景",
      "children": []
    },
    {
      "level": 3,
      "title": "解决",
      "slug": "解决",
      "children": []
    }
  ],
  "git": {},
  "filePathRelative": "guide/add.md"
}
