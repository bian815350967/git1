export const data = {
  "key": "v-fffb8e28",
  "path": "/guide/",
  "title": "首页",
  "lang": "en-US",
  "frontmatter": {
    "title": "首页",
    "date": "2022-01-04T00:00:00.000Z"
  },
  "excerpt": "",
  "headers": [],
  "git": {},
  "filePathRelative": "guide/README.md"
}
