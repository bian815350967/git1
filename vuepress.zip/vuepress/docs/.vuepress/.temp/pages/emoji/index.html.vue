<template><h1 id="emoji-表情" tabindex="-1"><a class="header-anchor" href="#emoji-表情" aria-hidden="true">#</a> Emoji 表情</h1>
<p>将对应 emoji 表情的符号码复制后输入你的 markdown 文本即可显示 emoji 表情。
如<code>:blush:</code>，显示为😊</p>
<h2 id="人物" tabindex="-1"><a class="header-anchor" href="#人物" aria-hidden="true">#</a> 人物</h2>
<table>
<thead>
<tr>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center"><code>:bowtie:</code></td>
<td style="text-align:center">:bowtie:</td>
<td style="text-align:center"><code>:smile:</code></td>
<td style="text-align:center">😄</td>
<td style="text-align:center"><code>:laughing:</code></td>
<td style="text-align:center">😆</td>
</tr>
<tr>
<td style="text-align:center"><code>:blush:</code></td>
<td style="text-align:center">😊</td>
<td style="text-align:center"><code>:smiley:</code></td>
<td style="text-align:center">😃</td>
<td style="text-align:center"><code>:relaxed:</code></td>
<td style="text-align:center">☺️</td>
</tr>
<tr>
<td style="text-align:center"><code>:smirk:</code></td>
<td style="text-align:center">😏</td>
<td style="text-align:center"><code>:heart_eyes:</code></td>
<td style="text-align:center">😍</td>
<td style="text-align:center"><code>:kissing_heart:</code></td>
<td style="text-align:center">😘</td>
</tr>
<tr>
<td style="text-align:center"><code>:kissing_closed_eyes:</code></td>
<td style="text-align:center">😚</td>
<td style="text-align:center"><code>:flushed:</code></td>
<td style="text-align:center">😳</td>
<td style="text-align:center"><code>:relieved:</code></td>
<td style="text-align:center">😌</td>
</tr>
<tr>
<td style="text-align:center"><code>:satisfied:</code></td>
<td style="text-align:center">😆</td>
<td style="text-align:center"><code>:grin:</code></td>
<td style="text-align:center">😁</td>
<td style="text-align:center"><code>:wink:</code></td>
<td style="text-align:center">😉</td>
</tr>
<tr>
<td style="text-align:center"><code>:stuck_out_tongue_winking_eye:</code></td>
<td style="text-align:center">😜</td>
<td style="text-align:center"><code>:stuck_out_tongue_closed_eyes:</code></td>
<td style="text-align:center">😝</td>
<td style="text-align:center"><code>:grinning:</code></td>
<td style="text-align:center">😀</td>
</tr>
<tr>
<td style="text-align:center"><code>:kissing:</code></td>
<td style="text-align:center">😗</td>
<td style="text-align:center"><code>:kissing_smiling_eyes:</code></td>
<td style="text-align:center">😙</td>
<td style="text-align:center"><code>:stuck_out_tongue:</code></td>
<td style="text-align:center">😛</td>
</tr>
<tr>
<td style="text-align:center"><code>:sleeping:</code></td>
<td style="text-align:center">😴</td>
<td style="text-align:center"><code>:worried:</code></td>
<td style="text-align:center">😟</td>
<td style="text-align:center"><code>:frowning:</code></td>
<td style="text-align:center">😦</td>
</tr>
<tr>
<td style="text-align:center"><code>:anguished:</code></td>
<td style="text-align:center">😧</td>
<td style="text-align:center"><code>:open_mouth:</code></td>
<td style="text-align:center">😮</td>
<td style="text-align:center"><code>:grimacing:</code></td>
<td style="text-align:center">😬</td>
</tr>
<tr>
<td style="text-align:center"><code>:confused:</code></td>
<td style="text-align:center">😕</td>
<td style="text-align:center"><code>:hushed:</code></td>
<td style="text-align:center">😯</td>
<td style="text-align:center"><code>:expressionless:</code></td>
<td style="text-align:center">😑</td>
</tr>
<tr>
<td style="text-align:center"><code>:unamused:</code></td>
<td style="text-align:center">😒</td>
<td style="text-align:center"><code>:sweat_smile:</code></td>
<td style="text-align:center">😅</td>
<td style="text-align:center"><code>:sweat:</code></td>
<td style="text-align:center">😓</td>
</tr>
<tr>
<td style="text-align:center"><code>:disappointed_relieved:</code></td>
<td style="text-align:center">😥</td>
<td style="text-align:center"><code>:weary:</code></td>
<td style="text-align:center">😩</td>
<td style="text-align:center"><code>:pensive:</code></td>
<td style="text-align:center">😔</td>
</tr>
<tr>
<td style="text-align:center"><code>:disappointed:</code></td>
<td style="text-align:center">😞</td>
<td style="text-align:center"><code>:confounded:</code></td>
<td style="text-align:center">😖</td>
<td style="text-align:center"><code>:fearful:</code></td>
<td style="text-align:center">😨</td>
</tr>
<tr>
<td style="text-align:center"><code>:cold_sweat:</code></td>
<td style="text-align:center">😰</td>
<td style="text-align:center"><code>:persevere:</code></td>
<td style="text-align:center">😣</td>
<td style="text-align:center"><code>:cry:</code></td>
<td style="text-align:center">😢</td>
</tr>
<tr>
<td style="text-align:center"><code>:sob:</code></td>
<td style="text-align:center">😭</td>
<td style="text-align:center"><code>:joy:</code></td>
<td style="text-align:center">😂</td>
<td style="text-align:center"><code>:astonished:</code></td>
<td style="text-align:center">😲</td>
</tr>
<tr>
<td style="text-align:center"><code>:scream:</code></td>
<td style="text-align:center">😱</td>
<td style="text-align:center"><code>:neckbeard:</code></td>
<td style="text-align:center">:neckbeard:</td>
<td style="text-align:center"><code>:tired_face:</code></td>
<td style="text-align:center">😫</td>
</tr>
<tr>
<td style="text-align:center"><code>:angry:</code></td>
<td style="text-align:center">😠</td>
<td style="text-align:center"><code>:rage:</code></td>
<td style="text-align:center">😡</td>
<td style="text-align:center"><code>:triumph:</code></td>
<td style="text-align:center">😤</td>
</tr>
<tr>
<td style="text-align:center"><code>:sleepy:</code></td>
<td style="text-align:center">😪</td>
<td style="text-align:center"><code>:yum:</code></td>
<td style="text-align:center">😋</td>
<td style="text-align:center"><code>:mask:</code></td>
<td style="text-align:center">😷</td>
</tr>
<tr>
<td style="text-align:center"><code>:sunglasses:</code></td>
<td style="text-align:center">😎</td>
<td style="text-align:center"><code>:dizzy_face:</code></td>
<td style="text-align:center">😵</td>
<td style="text-align:center"><code>:imp:</code></td>
<td style="text-align:center">👿</td>
</tr>
<tr>
<td style="text-align:center"><code>:smiling_imp:</code></td>
<td style="text-align:center">😈</td>
<td style="text-align:center"><code>:neutral_face:</code></td>
<td style="text-align:center">😐</td>
<td style="text-align:center"><code>:no_mouth:</code></td>
<td style="text-align:center">😶</td>
</tr>
<tr>
<td style="text-align:center"><code>:innocent:</code></td>
<td style="text-align:center">😇</td>
<td style="text-align:center"><code>:alien:</code></td>
<td style="text-align:center">👽</td>
<td style="text-align:center"><code>:yellow_heart:</code></td>
<td style="text-align:center">💛</td>
</tr>
<tr>
<td style="text-align:center"><code>:blue_heart:</code></td>
<td style="text-align:center">💙</td>
<td style="text-align:center"><code>:purple_heart:</code></td>
<td style="text-align:center">💜</td>
<td style="text-align:center"><code>:heart:</code></td>
<td style="text-align:center">❤️</td>
</tr>
<tr>
<td style="text-align:center"><code>:green_heart:</code></td>
<td style="text-align:center">💚</td>
<td style="text-align:center"><code>:broken_heart:</code></td>
<td style="text-align:center">💔</td>
<td style="text-align:center"><code>:heartbeat:</code></td>
<td style="text-align:center">💓</td>
</tr>
<tr>
<td style="text-align:center"><code>:heartpulse:</code></td>
<td style="text-align:center">💗</td>
<td style="text-align:center"><code>:two_hearts:</code></td>
<td style="text-align:center">💕</td>
<td style="text-align:center"><code>:revolving_hearts:</code></td>
<td style="text-align:center">💞</td>
</tr>
<tr>
<td style="text-align:center"><code>:cupid:</code></td>
<td style="text-align:center">💘</td>
<td style="text-align:center"><code>:sparkling_heart:</code></td>
<td style="text-align:center">💖</td>
<td style="text-align:center"><code>:sparkles:</code></td>
<td style="text-align:center">✨</td>
</tr>
<tr>
<td style="text-align:center"><code>:star:</code></td>
<td style="text-align:center">⭐</td>
<td style="text-align:center"><code>:star2:</code></td>
<td style="text-align:center">🌟</td>
<td style="text-align:center"><code>:dizzy:</code></td>
<td style="text-align:center">💫</td>
</tr>
<tr>
<td style="text-align:center"><code>:boom:</code></td>
<td style="text-align:center">💥</td>
<td style="text-align:center"><code>:collision:</code></td>
<td style="text-align:center">💥</td>
<td style="text-align:center"><code>:anger:</code></td>
<td style="text-align:center">💢</td>
</tr>
<tr>
<td style="text-align:center"><code>:exclamation:</code></td>
<td style="text-align:center">❗</td>
<td style="text-align:center"><code>:question:</code></td>
<td style="text-align:center">❓</td>
<td style="text-align:center"><code>:grey_exclamation:</code></td>
<td style="text-align:center">❕</td>
</tr>
<tr>
<td style="text-align:center"><code>:grey_question:</code></td>
<td style="text-align:center">❔</td>
<td style="text-align:center"><code>:zzz:</code></td>
<td style="text-align:center">💤</td>
<td style="text-align:center"><code>:dash:</code></td>
<td style="text-align:center">💨</td>
</tr>
<tr>
<td style="text-align:center"><code>:sweat_drops:</code></td>
<td style="text-align:center">💦</td>
<td style="text-align:center"><code>:notes:</code></td>
<td style="text-align:center">🎶</td>
<td style="text-align:center"><code>:musical_note:</code></td>
<td style="text-align:center">🎵</td>
</tr>
<tr>
<td style="text-align:center"><code>:fire:</code></td>
<td style="text-align:center">🔥</td>
<td style="text-align:center"><code>:hankey:</code></td>
<td style="text-align:center">💩</td>
<td style="text-align:center"><code>:poop:</code></td>
<td style="text-align:center">💩</td>
</tr>
<tr>
<td style="text-align:center"><code>::</code></td>
<td style="text-align:center">💩</td>
<td style="text-align:center"><code>:+1:</code></td>
<td style="text-align:center">👍</td>
<td style="text-align:center"><code>:thumbsup:</code></td>
<td style="text-align:center">👍</td>
</tr>
<tr>
<td style="text-align:center"><code>:-1:</code></td>
<td style="text-align:center">👎</td>
<td style="text-align:center"><code>:thumbsdown:</code></td>
<td style="text-align:center">👎</td>
<td style="text-align:center"><code>:ok_hand:</code></td>
<td style="text-align:center">👌</td>
</tr>
<tr>
<td style="text-align:center"><code>:punch:</code></td>
<td style="text-align:center">👊</td>
<td style="text-align:center"><code>:facepunch:</code></td>
<td style="text-align:center">👊</td>
<td style="text-align:center"><code>:fist:</code></td>
<td style="text-align:center">✊</td>
</tr>
<tr>
<td style="text-align:center"><code>:v:</code></td>
<td style="text-align:center">✌️</td>
<td style="text-align:center"><code>:wave:</code></td>
<td style="text-align:center">👋</td>
<td style="text-align:center"><code>:hand:</code></td>
<td style="text-align:center">✋</td>
</tr>
<tr>
<td style="text-align:center"><code>:raised_hand:</code></td>
<td style="text-align:center">✋</td>
<td style="text-align:center"><code>:open_hands:</code></td>
<td style="text-align:center">👐</td>
<td style="text-align:center"><code>:point_up:</code></td>
<td style="text-align:center">☝️</td>
</tr>
<tr>
<td style="text-align:center"><code>:point_down:</code></td>
<td style="text-align:center">👇</td>
<td style="text-align:center"><code>:point_left:</code></td>
<td style="text-align:center">👈</td>
<td style="text-align:center"><code>:point_right:</code></td>
<td style="text-align:center">👉</td>
</tr>
<tr>
<td style="text-align:center"><code>:raised_hands:</code></td>
<td style="text-align:center">🙌</td>
<td style="text-align:center"><code>:pray:</code></td>
<td style="text-align:center">🙏</td>
<td style="text-align:center"><code>:point_up_2:</code></td>
<td style="text-align:center">👆</td>
</tr>
<tr>
<td style="text-align:center"><code>:clap:</code></td>
<td style="text-align:center">👏</td>
<td style="text-align:center"><code>:muscle:</code></td>
<td style="text-align:center">💪</td>
<td style="text-align:center"><code>:metal:</code></td>
<td style="text-align:center">🤘</td>
</tr>
<tr>
<td style="text-align:center"><code>:fu:</code></td>
<td style="text-align:center">🖕</td>
<td style="text-align:center"><code>:walking:</code></td>
<td style="text-align:center">🚶</td>
<td style="text-align:center"><code>:runner:</code></td>
<td style="text-align:center">🏃</td>
</tr>
<tr>
<td style="text-align:center"><code>:running:</code></td>
<td style="text-align:center">🏃</td>
<td style="text-align:center"><code>:couple:</code></td>
<td style="text-align:center">👫</td>
<td style="text-align:center"><code>:family:</code></td>
<td style="text-align:center">👪</td>
</tr>
<tr>
<td style="text-align:center"><code>:two_men_holding_hands:</code></td>
<td style="text-align:center">👬</td>
<td style="text-align:center"><code>:two_women_holding_hands:</code></td>
<td style="text-align:center">👭</td>
<td style="text-align:center"><code>:dancer:</code></td>
<td style="text-align:center">💃</td>
</tr>
<tr>
<td style="text-align:center"><code>:dancers:</code></td>
<td style="text-align:center">👯</td>
<td style="text-align:center"><code>:ok_woman:</code></td>
<td style="text-align:center">🙆‍♀️</td>
<td style="text-align:center"><code>:no_good:</code></td>
<td style="text-align:center">🙅</td>
</tr>
<tr>
<td style="text-align:center"><code>:information_desk_person:</code></td>
<td style="text-align:center">💁</td>
<td style="text-align:center"><code>:raising_hand:</code></td>
<td style="text-align:center">🙋</td>
<td style="text-align:center"><code>:bride_with_veil:</code></td>
<td style="text-align:center">👰‍♀️</td>
</tr>
<tr>
<td style="text-align:center"><code>:person_with_pouting_face:</code></td>
<td style="text-align:center">:person_with_pouting_face:</td>
<td style="text-align:center"><code>:person_frowning:</code></td>
<td style="text-align:center">:person_frowning:</td>
<td style="text-align:center"><code>:bow:</code></td>
<td style="text-align:center">🙇</td>
</tr>
<tr>
<td style="text-align:center"><code>:couplekiss:</code></td>
<td style="text-align:center">💏</td>
<td style="text-align:center"><code>:couple_with_heart:</code></td>
<td style="text-align:center">💑</td>
<td style="text-align:center"><code>:massage:</code></td>
<td style="text-align:center">💆</td>
</tr>
<tr>
<td style="text-align:center"><code>:haircut:</code></td>
<td style="text-align:center">💇</td>
<td style="text-align:center"><code>:nail_care:</code></td>
<td style="text-align:center">💅</td>
<td style="text-align:center"><code>:boy:</code></td>
<td style="text-align:center">👦</td>
</tr>
<tr>
<td style="text-align:center"><code>:girl:</code></td>
<td style="text-align:center">👧</td>
<td style="text-align:center"><code>:woman:</code></td>
<td style="text-align:center">👩</td>
<td style="text-align:center"><code>:man:</code></td>
<td style="text-align:center">👨</td>
</tr>
<tr>
<td style="text-align:center"><code>:baby:</code></td>
<td style="text-align:center">👶</td>
<td style="text-align:center"><code>:older_woman:</code></td>
<td style="text-align:center">👵</td>
<td style="text-align:center"><code>:older_man:</code></td>
<td style="text-align:center">👴</td>
</tr>
<tr>
<td style="text-align:center"><code>:person_with_blond_hair:</code></td>
<td style="text-align:center">:person_with_blond_hair:</td>
<td style="text-align:center"><code>:man_with_gua_pi_mao:</code></td>
<td style="text-align:center">👲</td>
<td style="text-align:center"><code>:man_with_turban:</code></td>
<td style="text-align:center">👳‍♂️</td>
</tr>
<tr>
<td style="text-align:center"><code>:construction_worker:</code></td>
<td style="text-align:center">👷</td>
<td style="text-align:center"><code>:cop:</code></td>
<td style="text-align:center">👮</td>
<td style="text-align:center"><code>:angel:</code></td>
<td style="text-align:center">👼</td>
</tr>
<tr>
<td style="text-align:center"><code>:princess:</code></td>
<td style="text-align:center">👸</td>
<td style="text-align:center"><code>:smiley_cat:</code></td>
<td style="text-align:center">😺</td>
<td style="text-align:center"><code>:smile_cat:</code></td>
<td style="text-align:center">😸</td>
</tr>
<tr>
<td style="text-align:center"><code>:heart_eyes_cat:</code></td>
<td style="text-align:center">😻</td>
<td style="text-align:center"><code>:kissing_cat:</code></td>
<td style="text-align:center">😽</td>
<td style="text-align:center"><code>:smirk_cat:</code></td>
<td style="text-align:center">😼</td>
</tr>
<tr>
<td style="text-align:center"><code>:scream_cat:</code></td>
<td style="text-align:center">🙀</td>
<td style="text-align:center"><code>:crying_cat_face:</code></td>
<td style="text-align:center">😿</td>
<td style="text-align:center"><code>:joy_cat:</code></td>
<td style="text-align:center">😹</td>
</tr>
<tr>
<td style="text-align:center"><code>:pouting_cat:</code></td>
<td style="text-align:center">😾</td>
<td style="text-align:center"><code>:japanese_ogre:</code></td>
<td style="text-align:center">👹</td>
<td style="text-align:center"><code>:japanese_goblin:</code></td>
<td style="text-align:center">👺</td>
</tr>
<tr>
<td style="text-align:center"><code>:see_no_evil:</code></td>
<td style="text-align:center">🙈</td>
<td style="text-align:center"><code>:hear_no_evil:</code></td>
<td style="text-align:center">🙉</td>
<td style="text-align:center"><code>:speak_no_evil:</code></td>
<td style="text-align:center">🙊</td>
</tr>
<tr>
<td style="text-align:center"><code>:guardsman:</code></td>
<td style="text-align:center">💂‍♂️</td>
<td style="text-align:center"><code>:skull:</code></td>
<td style="text-align:center">💀</td>
<td style="text-align:center"><code>:feet:</code></td>
<td style="text-align:center">🐾</td>
</tr>
<tr>
<td style="text-align:center"><code>:lips:</code></td>
<td style="text-align:center">👄</td>
<td style="text-align:center"><code>:kiss:</code></td>
<td style="text-align:center">💋</td>
<td style="text-align:center"><code>:droplet:</code></td>
<td style="text-align:center">💧</td>
</tr>
<tr>
<td style="text-align:center"><code>:ear:</code></td>
<td style="text-align:center">👂</td>
<td style="text-align:center"><code>:eyes:</code></td>
<td style="text-align:center">👀</td>
<td style="text-align:center"><code>:nose:</code></td>
<td style="text-align:center">👃</td>
</tr>
<tr>
<td style="text-align:center"><code>:tongue:</code></td>
<td style="text-align:center">👅</td>
<td style="text-align:center"><code>:love_letter:</code></td>
<td style="text-align:center">💌</td>
<td style="text-align:center"><code>:bust_in_silhouette:</code></td>
<td style="text-align:center">👤</td>
</tr>
<tr>
<td style="text-align:center"><code>:busts_in_silhouette:</code></td>
<td style="text-align:center">👥</td>
<td style="text-align:center"><code>:speech_balloon:</code></td>
<td style="text-align:center">💬</td>
<td style="text-align:center"><code>:thought_balloon:</code></td>
<td style="text-align:center">💭</td>
</tr>
<tr>
<td style="text-align:center"><code>:feelsgood:</code></td>
<td style="text-align:center">:feelsgood:</td>
<td style="text-align:center"><code>:finnadie:</code></td>
<td style="text-align:center">:finnadie:</td>
<td style="text-align:center"><code>:goberserk:</code></td>
<td style="text-align:center">:goberserk:</td>
</tr>
<tr>
<td style="text-align:center"><code>:godmode:</code></td>
<td style="text-align:center">:godmode:</td>
<td style="text-align:center"><code>:hurtrealbad:</code></td>
<td style="text-align:center">:hurtrealbad:</td>
<td style="text-align:center"><code>:rage1:</code></td>
<td style="text-align:center">:rage1:</td>
</tr>
<tr>
<td style="text-align:center"><code>:rage2:</code></td>
<td style="text-align:center">:rage2:</td>
<td style="text-align:center"><code>:rage3:</code></td>
<td style="text-align:center">:rage3:</td>
<td style="text-align:center"><code>:rage4:</code></td>
<td style="text-align:center">:rage4:</td>
</tr>
<tr>
<td style="text-align:center"><code>:suspect:</code></td>
<td style="text-align:center">:suspect:</td>
<td style="text-align:center"><code>:trollface:</code></td>
<td style="text-align:center">:trollface:</td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
</tr>
</tbody>
</table>
<h2 id="自然" tabindex="-1"><a class="header-anchor" href="#自然" aria-hidden="true">#</a> 自然</h2>
<table>
<thead>
<tr>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center"><code>:sunny:</code></td>
<td style="text-align:center">☀️</td>
<td style="text-align:center"><code>:umbrella:</code></td>
<td style="text-align:center">☔</td>
<td style="text-align:center"><code>:cloud:</code></td>
<td style="text-align:center">☁️</td>
</tr>
<tr>
<td style="text-align:center"><code>:snowflake:</code></td>
<td style="text-align:center">❄️</td>
<td style="text-align:center"><code>:snowman:</code></td>
<td style="text-align:center">⛄</td>
<td style="text-align:center"><code>:zap:</code></td>
<td style="text-align:center">⚡</td>
</tr>
<tr>
<td style="text-align:center"><code>:cyclone:</code></td>
<td style="text-align:center">🌀</td>
<td style="text-align:center"><code>:foggy:</code></td>
<td style="text-align:center">🌁</td>
<td style="text-align:center"><code>:ocean:</code></td>
<td style="text-align:center">🌊</td>
</tr>
<tr>
<td style="text-align:center"><code>:cat:</code></td>
<td style="text-align:center">🐱</td>
<td style="text-align:center"><code>:dog:</code></td>
<td style="text-align:center">🐶</td>
<td style="text-align:center"><code>:mouse:</code></td>
<td style="text-align:center">🐭</td>
</tr>
<tr>
<td style="text-align:center"><code>:hamster:</code></td>
<td style="text-align:center">🐹</td>
<td style="text-align:center"><code>:rabbit:</code></td>
<td style="text-align:center">🐰</td>
<td style="text-align:center"><code>:wolf:</code></td>
<td style="text-align:center">🐺</td>
</tr>
<tr>
<td style="text-align:center"><code>:frog:</code></td>
<td style="text-align:center">🐸</td>
<td style="text-align:center"><code>:tiger:</code></td>
<td style="text-align:center">🐯</td>
<td style="text-align:center"><code>:koala:</code></td>
<td style="text-align:center">🐨</td>
</tr>
<tr>
<td style="text-align:center"><code>:bear:</code></td>
<td style="text-align:center">🐻</td>
<td style="text-align:center"><code>:pig:</code></td>
<td style="text-align:center">🐷</td>
<td style="text-align:center"><code>:pig_nose:</code></td>
<td style="text-align:center">🐽</td>
</tr>
<tr>
<td style="text-align:center"><code>:cow:</code></td>
<td style="text-align:center">🐮</td>
<td style="text-align:center"><code>:boar:</code></td>
<td style="text-align:center">🐗</td>
<td style="text-align:center"><code>:monkey_face:</code></td>
<td style="text-align:center">🐵</td>
</tr>
<tr>
<td style="text-align:center"><code>:monkey:</code></td>
<td style="text-align:center">🐒</td>
<td style="text-align:center"><code>:horse:</code></td>
<td style="text-align:center">🐴</td>
<td style="text-align:center"><code>:racehorse:</code></td>
<td style="text-align:center">🐎</td>
</tr>
<tr>
<td style="text-align:center"><code>:camel:</code></td>
<td style="text-align:center">🐫</td>
<td style="text-align:center"><code>:sheep:</code></td>
<td style="text-align:center">🐑</td>
<td style="text-align:center"><code>:elephant:</code></td>
<td style="text-align:center">🐘</td>
</tr>
<tr>
<td style="text-align:center"><code>:panda_face:</code></td>
<td style="text-align:center">🐼</td>
<td style="text-align:center"><code>:snake:</code></td>
<td style="text-align:center">🐍</td>
<td style="text-align:center"><code>:bird:</code></td>
<td style="text-align:center">🐦</td>
</tr>
<tr>
<td style="text-align:center"><code>:baby_chick:</code></td>
<td style="text-align:center">🐤</td>
<td style="text-align:center"><code>:hatched_chick:</code></td>
<td style="text-align:center">🐥</td>
<td style="text-align:center"><code>:hatching_chick:</code></td>
<td style="text-align:center">🐣</td>
</tr>
<tr>
<td style="text-align:center"><code>:chicken:</code></td>
<td style="text-align:center">🐔</td>
<td style="text-align:center"><code>:penguin:</code></td>
<td style="text-align:center">🐧</td>
<td style="text-align:center"><code>:turtle:</code></td>
<td style="text-align:center">🐢</td>
</tr>
<tr>
<td style="text-align:center"><code>:bug:</code></td>
<td style="text-align:center">🐛</td>
<td style="text-align:center"><code>:honeybee:</code></td>
<td style="text-align:center">🐝</td>
<td style="text-align:center"><code>:ant:</code></td>
<td style="text-align:center">🐜</td>
</tr>
<tr>
<td style="text-align:center"><code>:beetle:</code></td>
<td style="text-align:center">🪲</td>
<td style="text-align:center"><code>:snail:</code></td>
<td style="text-align:center">🐌</td>
<td style="text-align:center"><code>:octopus:</code></td>
<td style="text-align:center">🐙</td>
</tr>
<tr>
<td style="text-align:center"><code>:tropical_fish:</code></td>
<td style="text-align:center">🐠</td>
<td style="text-align:center"><code>:fish:</code></td>
<td style="text-align:center">🐟</td>
<td style="text-align:center"><code>:whale:</code></td>
<td style="text-align:center">🐳</td>
</tr>
<tr>
<td style="text-align:center"><code>:whale2:</code></td>
<td style="text-align:center">🐋</td>
<td style="text-align:center"><code>:dolphin:</code></td>
<td style="text-align:center">🐬</td>
<td style="text-align:center"><code>:cow2:</code></td>
<td style="text-align:center">🐄</td>
</tr>
<tr>
<td style="text-align:center"><code>:ram:</code></td>
<td style="text-align:center">🐏</td>
<td style="text-align:center"><code>:rat:</code></td>
<td style="text-align:center">🐀</td>
<td style="text-align:center"><code>:water_buffalo:</code></td>
<td style="text-align:center">🐃</td>
</tr>
<tr>
<td style="text-align:center"><code>:tiger2:</code></td>
<td style="text-align:center">🐅</td>
<td style="text-align:center"><code>:rabbit2:</code></td>
<td style="text-align:center">🐇</td>
<td style="text-align:center"><code>:dragon:</code></td>
<td style="text-align:center">🐉</td>
</tr>
<tr>
<td style="text-align:center"><code>:goat:</code></td>
<td style="text-align:center">🐐</td>
<td style="text-align:center"><code>:rooster:</code></td>
<td style="text-align:center">🐓</td>
<td style="text-align:center"><code>:dog2:</code></td>
<td style="text-align:center">🐕</td>
</tr>
<tr>
<td style="text-align:center"><code>:pig2:</code></td>
<td style="text-align:center">🐖</td>
<td style="text-align:center"><code>:mouse2:</code></td>
<td style="text-align:center">🐁</td>
<td style="text-align:center"><code>:ox:</code></td>
<td style="text-align:center">🐂</td>
</tr>
<tr>
<td style="text-align:center"><code>:dragon_face:</code></td>
<td style="text-align:center">🐲</td>
<td style="text-align:center"><code>:blowfish:</code></td>
<td style="text-align:center">🐡</td>
<td style="text-align:center"><code>:crocodile:</code></td>
<td style="text-align:center">🐊</td>
</tr>
<tr>
<td style="text-align:center"><code>:dromedary_camel:</code></td>
<td style="text-align:center">🐪</td>
<td style="text-align:center"><code>:leopard:</code></td>
<td style="text-align:center">🐆</td>
<td style="text-align:center"><code>:cat2:</code></td>
<td style="text-align:center">🐈</td>
</tr>
<tr>
<td style="text-align:center"><code>:poodle:</code></td>
<td style="text-align:center">🐩</td>
<td style="text-align:center"><code>:paw_prints:</code></td>
<td style="text-align:center">🐾</td>
<td style="text-align:center"><code>:bouquet:</code></td>
<td style="text-align:center">💐</td>
</tr>
<tr>
<td style="text-align:center"><code>:cherry_blossom:</code></td>
<td style="text-align:center">🌸</td>
<td style="text-align:center"><code>:tulip:</code></td>
<td style="text-align:center">🌷</td>
<td style="text-align:center"><code>:four_leaf_clover:</code></td>
<td style="text-align:center">🍀</td>
</tr>
<tr>
<td style="text-align:center"><code>:rose:</code></td>
<td style="text-align:center">🌹</td>
<td style="text-align:center"><code>:sunflower:</code></td>
<td style="text-align:center">🌻</td>
<td style="text-align:center"><code>:hibiscus:</code></td>
<td style="text-align:center">🌺</td>
</tr>
<tr>
<td style="text-align:center"><code>:maple_leaf:</code></td>
<td style="text-align:center">🍁</td>
<td style="text-align:center"><code>:leaves:</code></td>
<td style="text-align:center">🍃</td>
<td style="text-align:center"><code>:fallen_leaf:</code></td>
<td style="text-align:center">🍂</td>
</tr>
<tr>
<td style="text-align:center"><code>:herb:</code></td>
<td style="text-align:center">🌿</td>
<td style="text-align:center"><code>:mushroom:</code></td>
<td style="text-align:center">🍄</td>
<td style="text-align:center"><code>:cactus:</code></td>
<td style="text-align:center">🌵</td>
</tr>
<tr>
<td style="text-align:center"><code>:palm_tree:</code></td>
<td style="text-align:center">🌴</td>
<td style="text-align:center"><code>:evergreen_tree:</code></td>
<td style="text-align:center">🌲</td>
<td style="text-align:center"><code>:deciduous_tree:</code></td>
<td style="text-align:center">🌳</td>
</tr>
<tr>
<td style="text-align:center"><code>:chestnut:</code></td>
<td style="text-align:center">🌰</td>
<td style="text-align:center"><code>:seedling:</code></td>
<td style="text-align:center">🌱</td>
<td style="text-align:center"><code>:blossom:</code></td>
<td style="text-align:center">🌼</td>
</tr>
<tr>
<td style="text-align:center"><code>:ear_of_rice:</code></td>
<td style="text-align:center">🌾</td>
<td style="text-align:center"><code>:shell:</code></td>
<td style="text-align:center">🐚</td>
<td style="text-align:center"><code>:globe_with_meridians:</code></td>
<td style="text-align:center">🌐</td>
</tr>
<tr>
<td style="text-align:center"><code>:sun_with_face:</code></td>
<td style="text-align:center">🌞</td>
<td style="text-align:center"><code>:full_moon_with_face:</code></td>
<td style="text-align:center">🌝</td>
<td style="text-align:center"><code>:new_moon_with_face:</code></td>
<td style="text-align:center">🌚</td>
</tr>
<tr>
<td style="text-align:center"><code>:new_moon:</code></td>
<td style="text-align:center">🌑</td>
<td style="text-align:center"><code>:waxing_crescent_moon:</code></td>
<td style="text-align:center">🌒</td>
<td style="text-align:center"><code>:first_quarter_moon:</code></td>
<td style="text-align:center">🌓</td>
</tr>
<tr>
<td style="text-align:center"><code>:full_moon:</code></td>
<td style="text-align:center">🌕</td>
<td style="text-align:center"><code>:waning_gibbous_moon:</code></td>
<td style="text-align:center">🌖</td>
<td style="text-align:center"><code>:last_quarter_moon:</code></td>
<td style="text-align:center">🌗</td>
</tr>
<tr>
<td style="text-align:center"><code>:waning_crescent_moon:</code></td>
<td style="text-align:center">🌘</td>
<td style="text-align:center"><code>:last_quarter_moon_with_face:</code></td>
<td style="text-align:center">🌜</td>
<td style="text-align:center"><code>:first_quarter_moon_with_face:</code></td>
<td style="text-align:center">🌛</td>
</tr>
<tr>
<td style="text-align:center"><code>:moon:</code></td>
<td style="text-align:center">🌔</td>
<td style="text-align:center"><code>:earth_africa:</code></td>
<td style="text-align:center">🌍</td>
<td style="text-align:center"><code>:earth_americas:</code></td>
<td style="text-align:center">🌎</td>
</tr>
<tr>
<td style="text-align:center"><code>:earth_asia:</code></td>
<td style="text-align:center">🌏</td>
<td style="text-align:center"><code>:volcano:</code></td>
<td style="text-align:center">🌋</td>
<td style="text-align:center"><code>:milky_way:</code></td>
<td style="text-align:center">🌌</td>
</tr>
<tr>
<td style="text-align:center"><code>:partly_sunny:</code></td>
<td style="text-align:center">⛅</td>
<td style="text-align:center"><code>:octocat:</code></td>
<td style="text-align:center">:octocat:</td>
<td style="text-align:center"><code>:squirrel:</code></td>
<td style="text-align:center">:squirrel:</td>
</tr>
<tr>
<td style="text-align:center"><code>:waxing_gibbous_moon:</code></td>
<td style="text-align:center">🌔</td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
</tr>
</tbody>
</table>
<h2 id="物体" tabindex="-1"><a class="header-anchor" href="#物体" aria-hidden="true">#</a> 物体</h2>
<table>
<thead>
<tr>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center"><code>:bamboo:</code></td>
<td style="text-align:center">🎍</td>
<td style="text-align:center"><code>:gift_heart:</code></td>
<td style="text-align:center">💝</td>
<td style="text-align:center"><code>:dolls:</code></td>
<td style="text-align:center">🎎</td>
</tr>
<tr>
<td style="text-align:center"><code>:school_satchel:</code></td>
<td style="text-align:center">🎒</td>
<td style="text-align:center"><code>:mortar_board:</code></td>
<td style="text-align:center">🎓</td>
<td style="text-align:center"><code>:flags:</code></td>
<td style="text-align:center">🎏</td>
</tr>
<tr>
<td style="text-align:center"><code>:fireworks:</code></td>
<td style="text-align:center">🎆</td>
<td style="text-align:center"><code>:sparkler:</code></td>
<td style="text-align:center">🎇</td>
<td style="text-align:center"><code>:wind_chime:</code></td>
<td style="text-align:center">🎐</td>
</tr>
<tr>
<td style="text-align:center"><code>:rice_scene:</code></td>
<td style="text-align:center">🎑</td>
<td style="text-align:center"><code>:jack_o_lantern:</code></td>
<td style="text-align:center">🎃</td>
<td style="text-align:center"><code>:ghost:</code></td>
<td style="text-align:center">👻</td>
</tr>
<tr>
<td style="text-align:center"><code>:santa:</code></td>
<td style="text-align:center">🎅</td>
<td style="text-align:center"><code>:christmas_tree:</code></td>
<td style="text-align:center">🎄</td>
<td style="text-align:center"><code>:gift:</code></td>
<td style="text-align:center">🎁</td>
</tr>
<tr>
<td style="text-align:center"><code>:bell:</code></td>
<td style="text-align:center">🔔</td>
<td style="text-align:center"><code>:no_bell:</code></td>
<td style="text-align:center">🔕</td>
<td style="text-align:center"><code>:tanabata_tree:</code></td>
<td style="text-align:center">🎋</td>
</tr>
<tr>
<td style="text-align:center"><code>:tada:</code></td>
<td style="text-align:center">🎉</td>
<td style="text-align:center"><code>:confetti_ball:</code></td>
<td style="text-align:center">🎊</td>
<td style="text-align:center"><code>:balloon:</code></td>
<td style="text-align:center">🎈</td>
</tr>
<tr>
<td style="text-align:center"><code>:crystal_ball:</code></td>
<td style="text-align:center">🔮</td>
<td style="text-align:center"><code>:cd:</code></td>
<td style="text-align:center">💿</td>
<td style="text-align:center"><code>:dvd:</code></td>
<td style="text-align:center">📀</td>
</tr>
<tr>
<td style="text-align:center"><code>:floppy_disk:</code></td>
<td style="text-align:center">💾</td>
<td style="text-align:center"><code>:camera:</code></td>
<td style="text-align:center">📷</td>
<td style="text-align:center"><code>:video_camera:</code></td>
<td style="text-align:center">📹</td>
</tr>
<tr>
<td style="text-align:center"><code>:movie_camera:</code></td>
<td style="text-align:center">🎥</td>
<td style="text-align:center"><code>:computer:</code></td>
<td style="text-align:center">💻</td>
<td style="text-align:center"><code>:tv:</code></td>
<td style="text-align:center">📺</td>
</tr>
<tr>
<td style="text-align:center"><code>:iphone:</code></td>
<td style="text-align:center">📱</td>
<td style="text-align:center"><code>:phone:</code></td>
<td style="text-align:center">☎️</td>
<td style="text-align:center"><code>:telephone:</code></td>
<td style="text-align:center">☎️</td>
</tr>
<tr>
<td style="text-align:center"><code>:telephone_receiver:</code></td>
<td style="text-align:center">📞</td>
<td style="text-align:center"><code>:pager:</code></td>
<td style="text-align:center">📟</td>
<td style="text-align:center"><code>:fax:</code></td>
<td style="text-align:center">📠</td>
</tr>
<tr>
<td style="text-align:center"><code>:minidisc:</code></td>
<td style="text-align:center">💽</td>
<td style="text-align:center"><code>:vhs:</code></td>
<td style="text-align:center">📼</td>
<td style="text-align:center"><code>:sound:</code></td>
<td style="text-align:center">🔉</td>
</tr>
<tr>
<td style="text-align:center"><code>:speaker:</code></td>
<td style="text-align:center">🔈</td>
<td style="text-align:center"><code>:mute:</code></td>
<td style="text-align:center">🔇</td>
<td style="text-align:center"><code>:loudspeaker:</code></td>
<td style="text-align:center">📢</td>
</tr>
<tr>
<td style="text-align:center"><code>:mega:</code></td>
<td style="text-align:center">📣</td>
<td style="text-align:center"><code>:hourglass:</code></td>
<td style="text-align:center">⌛</td>
<td style="text-align:center"><code>:hourglass_flowing_sand:</code></td>
<td style="text-align:center">⏳</td>
</tr>
<tr>
<td style="text-align:center"><code>:alarm_clock:</code></td>
<td style="text-align:center">⏰</td>
<td style="text-align:center"><code>:watch:</code></td>
<td style="text-align:center">⌚</td>
<td style="text-align:center"><code>:radio:</code></td>
<td style="text-align:center">📻</td>
</tr>
<tr>
<td style="text-align:center"><code>:satellite:</code></td>
<td style="text-align:center">📡</td>
<td style="text-align:center"><code>:loop:</code></td>
<td style="text-align:center">➿</td>
<td style="text-align:center"><code>:mag:</code></td>
<td style="text-align:center">🔍</td>
</tr>
<tr>
<td style="text-align:center"><code>:mag_right:</code></td>
<td style="text-align:center">🔎</td>
<td style="text-align:center"><code>:unlock:</code></td>
<td style="text-align:center">🔓</td>
<td style="text-align:center"><code>:lock:</code></td>
<td style="text-align:center">🔒</td>
</tr>
<tr>
<td style="text-align:center"><code>:lock_with_ink_pen:</code></td>
<td style="text-align:center">🔏</td>
<td style="text-align:center"><code>:closed_lock_with_key:</code></td>
<td style="text-align:center">🔐</td>
<td style="text-align:center"><code>:key:</code></td>
<td style="text-align:center">🔑</td>
</tr>
<tr>
<td style="text-align:center"><code>:bulb:</code></td>
<td style="text-align:center">💡</td>
<td style="text-align:center"><code>:flashlight:</code></td>
<td style="text-align:center">🔦</td>
<td style="text-align:center"><code>:high_brightness:</code></td>
<td style="text-align:center">🔆</td>
</tr>
<tr>
<td style="text-align:center"><code>:low_brightness:</code></td>
<td style="text-align:center">🔅</td>
<td style="text-align:center"><code>:electric_plug:</code></td>
<td style="text-align:center">🔌</td>
<td style="text-align:center"><code>:battery:</code></td>
<td style="text-align:center">🔋</td>
</tr>
<tr>
<td style="text-align:center"><code>:calling:</code></td>
<td style="text-align:center">📲</td>
<td style="text-align:center"><code>:email:</code></td>
<td style="text-align:center">📧</td>
<td style="text-align:center"><code>:mailbox:</code></td>
<td style="text-align:center">📫</td>
</tr>
<tr>
<td style="text-align:center"><code>:postbox:</code></td>
<td style="text-align:center">📮</td>
<td style="text-align:center"><code>:bath:</code></td>
<td style="text-align:center">🛀</td>
<td style="text-align:center"><code>:bathtub:</code></td>
<td style="text-align:center">🛁</td>
</tr>
<tr>
<td style="text-align:center"><code>:shower:</code></td>
<td style="text-align:center">🚿</td>
<td style="text-align:center"><code>:toilet:</code></td>
<td style="text-align:center">🚽</td>
<td style="text-align:center"><code>:wrench:</code></td>
<td style="text-align:center">🔧</td>
</tr>
<tr>
<td style="text-align:center"><code>:nut_and_bolt:</code></td>
<td style="text-align:center">🔩</td>
<td style="text-align:center"><code>:hammer:</code></td>
<td style="text-align:center">🔨</td>
<td style="text-align:center"><code>:seat:</code></td>
<td style="text-align:center">💺</td>
</tr>
<tr>
<td style="text-align:center"><code>:moneybag:</code></td>
<td style="text-align:center">💰</td>
<td style="text-align:center"><code>:yen:</code></td>
<td style="text-align:center">💴</td>
<td style="text-align:center"><code>:dollar:</code></td>
<td style="text-align:center">💵</td>
</tr>
<tr>
<td style="text-align:center"><code>:pound:</code></td>
<td style="text-align:center">💷</td>
<td style="text-align:center"><code>:euro:</code></td>
<td style="text-align:center">💶</td>
<td style="text-align:center"><code>:credit_card:</code></td>
<td style="text-align:center">💳</td>
</tr>
<tr>
<td style="text-align:center"><code>:money_with_wings:</code></td>
<td style="text-align:center">💸</td>
<td style="text-align:center"><code>:e-mail:</code></td>
<td style="text-align:center">📧</td>
<td style="text-align:center"><code>:inbox_tray:</code></td>
<td style="text-align:center">📥</td>
</tr>
<tr>
<td style="text-align:center"><code>:outbox_tray:</code></td>
<td style="text-align:center">📤</td>
<td style="text-align:center"><code>:envelope:</code></td>
<td style="text-align:center">✉️</td>
<td style="text-align:center"><code>:incoming_envelope:</code></td>
<td style="text-align:center">📨</td>
</tr>
<tr>
<td style="text-align:center"><code>:postal_horn:</code></td>
<td style="text-align:center">📯</td>
<td style="text-align:center"><code>:mailbox_closed:</code></td>
<td style="text-align:center">📪</td>
<td style="text-align:center"><code>:mailbox_with_mail:</code></td>
<td style="text-align:center">📬</td>
</tr>
<tr>
<td style="text-align:center"><code>:mailbox_with_no_mail:</code></td>
<td style="text-align:center">📭</td>
<td style="text-align:center"><code>:door:</code></td>
<td style="text-align:center">🚪</td>
<td style="text-align:center"><code>:smoking:</code></td>
<td style="text-align:center">🚬</td>
</tr>
<tr>
<td style="text-align:center"><code>:bomb:</code></td>
<td style="text-align:center">💣</td>
<td style="text-align:center"><code>:gun:</code></td>
<td style="text-align:center">🔫</td>
<td style="text-align:center"><code>:hocho:</code></td>
<td style="text-align:center">🔪</td>
</tr>
<tr>
<td style="text-align:center"><code>:pill:</code></td>
<td style="text-align:center">💊</td>
<td style="text-align:center"><code>:syringe:</code></td>
<td style="text-align:center">💉</td>
<td style="text-align:center"><code>:page_facing_up:</code></td>
<td style="text-align:center">📄</td>
</tr>
<tr>
<td style="text-align:center"><code>:page_with_curl:</code></td>
<td style="text-align:center">📃</td>
<td style="text-align:center"><code>:bookmark_tabs:</code></td>
<td style="text-align:center">📑</td>
<td style="text-align:center"><code>:bar_chart:</code></td>
<td style="text-align:center">📊</td>
</tr>
<tr>
<td style="text-align:center"><code>:chart_with_upwards_trend:</code></td>
<td style="text-align:center">📈</td>
<td style="text-align:center"><code>:chart_with_downwards_trend:</code></td>
<td style="text-align:center">📉</td>
<td style="text-align:center"><code>:scroll:</code></td>
<td style="text-align:center">📜</td>
</tr>
<tr>
<td style="text-align:center"><code>:clipboard:</code></td>
<td style="text-align:center">📋</td>
<td style="text-align:center"><code>:calendar:</code></td>
<td style="text-align:center">📆</td>
<td style="text-align:center"><code>:date:</code></td>
<td style="text-align:center">📅</td>
</tr>
<tr>
<td style="text-align:center"><code>:card_index:</code></td>
<td style="text-align:center">📇</td>
<td style="text-align:center"><code>:file_folder:</code></td>
<td style="text-align:center">📁</td>
<td style="text-align:center"><code>:open_file_folder:</code></td>
<td style="text-align:center">📂</td>
</tr>
<tr>
<td style="text-align:center"><code>:scissors:</code></td>
<td style="text-align:center">✂️</td>
<td style="text-align:center"><code>:pushpin:</code></td>
<td style="text-align:center">📌</td>
<td style="text-align:center"><code>:paperclip:</code></td>
<td style="text-align:center">📎</td>
</tr>
<tr>
<td style="text-align:center"><code>:black_nib:</code></td>
<td style="text-align:center">✒️</td>
<td style="text-align:center"><code>:pencil2:</code></td>
<td style="text-align:center">✏️</td>
<td style="text-align:center"><code>:straight_ruler:</code></td>
<td style="text-align:center">📏</td>
</tr>
<tr>
<td style="text-align:center"><code>:triangular_ruler:</code></td>
<td style="text-align:center">📐</td>
<td style="text-align:center"><code>:closed_book:</code></td>
<td style="text-align:center">📕</td>
<td style="text-align:center"><code>:green_book:</code></td>
<td style="text-align:center">📗</td>
</tr>
<tr>
<td style="text-align:center"><code>:blue_book:</code></td>
<td style="text-align:center">📘</td>
<td style="text-align:center"><code>:orange_book:</code></td>
<td style="text-align:center">📙</td>
<td style="text-align:center"><code>:notebook:</code></td>
<td style="text-align:center">📓</td>
</tr>
<tr>
<td style="text-align:center"><code>:notebook_with_decorative_cover:</code></td>
<td style="text-align:center">📔</td>
<td style="text-align:center"><code>:ledger:</code></td>
<td style="text-align:center">📒</td>
<td style="text-align:center"><code>:books:</code></td>
<td style="text-align:center">📚</td>
</tr>
<tr>
<td style="text-align:center"><code>:bookmark:</code></td>
<td style="text-align:center">🔖</td>
<td style="text-align:center"><code>:microscope:</code></td>
<td style="text-align:center">🔬</td>
<td style="text-align:center"><code>:telescope:</code></td>
<td style="text-align:center">🔭</td>
</tr>
<tr>
<td style="text-align:center"><code>:name_badge:</code></td>
<td style="text-align:center">📛</td>
<td style="text-align:center"><code>:newspaper:</code></td>
<td style="text-align:center">📰</td>
<td style="text-align:center"><code>:football:</code></td>
<td style="text-align:center">🏈</td>
</tr>
<tr>
<td style="text-align:center"><code>:basketball:</code></td>
<td style="text-align:center">🏀</td>
<td style="text-align:center"><code>:soccer:</code></td>
<td style="text-align:center">⚽</td>
<td style="text-align:center"><code>:baseball:</code></td>
<td style="text-align:center">⚾</td>
</tr>
<tr>
<td style="text-align:center"><code>:tennis:</code></td>
<td style="text-align:center">🎾</td>
<td style="text-align:center"><code>:8ball:</code></td>
<td style="text-align:center">🎱</td>
<td style="text-align:center"><code>:rugby_football:</code></td>
<td style="text-align:center">🏉</td>
</tr>
<tr>
<td style="text-align:center"><code>:bowling:</code></td>
<td style="text-align:center">🎳</td>
<td style="text-align:center"><code>:golf:</code></td>
<td style="text-align:center">⛳</td>
<td style="text-align:center"><code>:mountain_bicyclist:</code></td>
<td style="text-align:center">🚵</td>
</tr>
<tr>
<td style="text-align:center"><code>:bicyclist:</code></td>
<td style="text-align:center">🚴</td>
<td style="text-align:center"><code>:horse_racing:</code></td>
<td style="text-align:center">🏇</td>
<td style="text-align:center"><code>:snowboarder:</code></td>
<td style="text-align:center">🏂</td>
</tr>
<tr>
<td style="text-align:center"><code>:swimmer:</code></td>
<td style="text-align:center">🏊</td>
<td style="text-align:center"><code>:surfer:</code></td>
<td style="text-align:center">🏄</td>
<td style="text-align:center"><code>:ski:</code></td>
<td style="text-align:center">🎿</td>
</tr>
<tr>
<td style="text-align:center"><code>:spades:</code></td>
<td style="text-align:center">♠️</td>
<td style="text-align:center"><code>:hearts:</code></td>
<td style="text-align:center">♥️</td>
<td style="text-align:center"><code>:clubs:</code></td>
<td style="text-align:center">♣️</td>
</tr>
<tr>
<td style="text-align:center"><code>:diamonds:</code></td>
<td style="text-align:center">♦️</td>
<td style="text-align:center"><code>:gem:</code></td>
<td style="text-align:center">💎</td>
<td style="text-align:center"><code>:ring:</code></td>
<td style="text-align:center">💍</td>
</tr>
<tr>
<td style="text-align:center"><code>:trophy:</code></td>
<td style="text-align:center">🏆</td>
<td style="text-align:center"><code>:musical_score:</code></td>
<td style="text-align:center">🎼</td>
<td style="text-align:center"><code>:musical_keyboard:</code></td>
<td style="text-align:center">🎹</td>
</tr>
<tr>
<td style="text-align:center"><code>:violin:</code></td>
<td style="text-align:center">🎻</td>
<td style="text-align:center"><code>:space_invader:</code></td>
<td style="text-align:center">👾</td>
<td style="text-align:center"><code>:video_game:</code></td>
<td style="text-align:center">🎮</td>
</tr>
<tr>
<td style="text-align:center"><code>:black_joker:</code></td>
<td style="text-align:center">🃏</td>
<td style="text-align:center"><code>:flower_playing_cards:</code></td>
<td style="text-align:center">🎴</td>
<td style="text-align:center"><code>:game_die:</code></td>
<td style="text-align:center">🎲</td>
</tr>
<tr>
<td style="text-align:center"><code>:dart:</code></td>
<td style="text-align:center">🎯</td>
<td style="text-align:center"><code>:mahjong:</code></td>
<td style="text-align:center">🀄</td>
<td style="text-align:center"><code>:clapper:</code></td>
<td style="text-align:center">🎬</td>
</tr>
<tr>
<td style="text-align:center"><code>:memo:</code></td>
<td style="text-align:center">📝</td>
<td style="text-align:center"><code>:pencil:</code></td>
<td style="text-align:center">📝</td>
<td style="text-align:center"><code>:book:</code></td>
<td style="text-align:center">📖</td>
</tr>
<tr>
<td style="text-align:center"><code>:art:</code></td>
<td style="text-align:center">🎨</td>
<td style="text-align:center"><code>:microphone:</code></td>
<td style="text-align:center">🎤</td>
<td style="text-align:center"><code>:headphones:</code></td>
<td style="text-align:center">🎧</td>
</tr>
<tr>
<td style="text-align:center"><code>:trumpet:</code></td>
<td style="text-align:center">🎺</td>
<td style="text-align:center"><code>:saxophone:</code></td>
<td style="text-align:center">🎷</td>
<td style="text-align:center"><code>:guitar:</code></td>
<td style="text-align:center">🎸</td>
</tr>
<tr>
<td style="text-align:center"><code>:shoe:</code></td>
<td style="text-align:center">👞</td>
<td style="text-align:center"><code>:sandal:</code></td>
<td style="text-align:center">👡</td>
<td style="text-align:center"><code>:high_heel:</code></td>
<td style="text-align:center">👠</td>
</tr>
<tr>
<td style="text-align:center"><code>:lipstick:</code></td>
<td style="text-align:center">💄</td>
<td style="text-align:center"><code>:boot:</code></td>
<td style="text-align:center">👢</td>
<td style="text-align:center"><code>:shirt:</code></td>
<td style="text-align:center">👕</td>
</tr>
<tr>
<td style="text-align:center"><code>:tshirt:</code></td>
<td style="text-align:center">👕</td>
<td style="text-align:center"><code>:necktie:</code></td>
<td style="text-align:center">👔</td>
<td style="text-align:center"><code>:womans_clothes:</code></td>
<td style="text-align:center">👚</td>
</tr>
<tr>
<td style="text-align:center"><code>:dress:</code></td>
<td style="text-align:center">👗</td>
<td style="text-align:center"><code>:running_shirt_with_sash:</code></td>
<td style="text-align:center">🎽</td>
<td style="text-align:center"><code>:jeans:</code></td>
<td style="text-align:center">👖</td>
</tr>
<tr>
<td style="text-align:center"><code>:kimono:</code></td>
<td style="text-align:center">👘</td>
<td style="text-align:center"><code>:bikini:</code></td>
<td style="text-align:center">👙</td>
<td style="text-align:center"><code>:ribbon:</code></td>
<td style="text-align:center">🎀</td>
</tr>
<tr>
<td style="text-align:center"><code>:tophat:</code></td>
<td style="text-align:center">🎩</td>
<td style="text-align:center"><code>:crown:</code></td>
<td style="text-align:center">👑</td>
<td style="text-align:center"><code>:womans_hat:</code></td>
<td style="text-align:center">👒</td>
</tr>
<tr>
<td style="text-align:center"><code>:mans_shoe:</code></td>
<td style="text-align:center">👞</td>
<td style="text-align:center"><code>:closed_umbrella:</code></td>
<td style="text-align:center">🌂</td>
<td style="text-align:center"><code>:briefcase:</code></td>
<td style="text-align:center">💼</td>
</tr>
<tr>
<td style="text-align:center"><code>:handbag:</code></td>
<td style="text-align:center">👜</td>
<td style="text-align:center"><code>:pouch:</code></td>
<td style="text-align:center">👝</td>
<td style="text-align:center"><code>:purse:</code></td>
<td style="text-align:center">👛</td>
</tr>
<tr>
<td style="text-align:center"><code>:eyeglasses:</code></td>
<td style="text-align:center">👓</td>
<td style="text-align:center"><code>:fishing_pole_and_fish:</code></td>
<td style="text-align:center">🎣</td>
<td style="text-align:center"><code>:coffee:</code></td>
<td style="text-align:center">☕</td>
</tr>
<tr>
<td style="text-align:center"><code>:tea:</code></td>
<td style="text-align:center">🍵</td>
<td style="text-align:center"><code>:sake:</code></td>
<td style="text-align:center">🍶</td>
<td style="text-align:center"><code>:baby_bottle:</code></td>
<td style="text-align:center">🍼</td>
</tr>
<tr>
<td style="text-align:center"><code>:beer:</code></td>
<td style="text-align:center">🍺</td>
<td style="text-align:center"><code>:beers:</code></td>
<td style="text-align:center">🍻</td>
<td style="text-align:center"><code>:cocktail:</code></td>
<td style="text-align:center">🍸</td>
</tr>
<tr>
<td style="text-align:center"><code>:tropical_drink:</code></td>
<td style="text-align:center">🍹</td>
<td style="text-align:center"><code>:wine_glass:</code></td>
<td style="text-align:center">🍷</td>
<td style="text-align:center"><code>:fork_and_knife:</code></td>
<td style="text-align:center">🍴</td>
</tr>
<tr>
<td style="text-align:center"><code>:pizza:</code></td>
<td style="text-align:center">🍕</td>
<td style="text-align:center"><code>:hamburger:</code></td>
<td style="text-align:center">🍔</td>
<td style="text-align:center"><code>:fries:</code></td>
<td style="text-align:center">🍟</td>
</tr>
<tr>
<td style="text-align:center"><code>:poultry_leg:</code></td>
<td style="text-align:center">🍗</td>
<td style="text-align:center"><code>:meat_on_bone:</code></td>
<td style="text-align:center">🍖</td>
<td style="text-align:center"><code>:spaghetti:</code></td>
<td style="text-align:center">🍝</td>
</tr>
<tr>
<td style="text-align:center"><code>:curry:</code></td>
<td style="text-align:center">🍛</td>
<td style="text-align:center"><code>:fried_shrimp:</code></td>
<td style="text-align:center">🍤</td>
<td style="text-align:center"><code>:bento:</code></td>
<td style="text-align:center">🍱</td>
</tr>
<tr>
<td style="text-align:center"><code>:sushi:</code></td>
<td style="text-align:center">🍣</td>
<td style="text-align:center"><code>:fish_cake:</code></td>
<td style="text-align:center">🍥</td>
<td style="text-align:center"><code>:rice_ball:</code></td>
<td style="text-align:center">🍙</td>
</tr>
<tr>
<td style="text-align:center"><code>:rice_cracker:</code></td>
<td style="text-align:center">🍘</td>
<td style="text-align:center"><code>:rice:</code></td>
<td style="text-align:center">🍚</td>
<td style="text-align:center"><code>:ramen:</code></td>
<td style="text-align:center">🍜</td>
</tr>
<tr>
<td style="text-align:center"><code>:stew:</code></td>
<td style="text-align:center">🍲</td>
<td style="text-align:center"><code>:oden:</code></td>
<td style="text-align:center">🍢</td>
<td style="text-align:center"><code>:dango:</code></td>
<td style="text-align:center">🍡</td>
</tr>
<tr>
<td style="text-align:center"><code>:egg:</code></td>
<td style="text-align:center">🥚</td>
<td style="text-align:center"><code>:bread:</code></td>
<td style="text-align:center">🍞</td>
<td style="text-align:center"><code>:doughnut:</code></td>
<td style="text-align:center">🍩</td>
</tr>
<tr>
<td style="text-align:center"><code>:custard:</code></td>
<td style="text-align:center">🍮</td>
<td style="text-align:center"><code>:icecream:</code></td>
<td style="text-align:center">🍦</td>
<td style="text-align:center"><code>:ice_cream:</code></td>
<td style="text-align:center">🍨</td>
</tr>
<tr>
<td style="text-align:center"><code>:shaved_ice:</code></td>
<td style="text-align:center">🍧</td>
<td style="text-align:center"><code>:birthday:</code></td>
<td style="text-align:center">🎂</td>
<td style="text-align:center"><code>:cake:</code></td>
<td style="text-align:center">🍰</td>
</tr>
<tr>
<td style="text-align:center"><code>:cookie:</code></td>
<td style="text-align:center">🍪</td>
<td style="text-align:center"><code>:chocolate_bar:</code></td>
<td style="text-align:center">🍫</td>
<td style="text-align:center"><code>:candy:</code></td>
<td style="text-align:center">🍬</td>
</tr>
<tr>
<td style="text-align:center"><code>:lollipop:</code></td>
<td style="text-align:center">🍭</td>
<td style="text-align:center"><code>:honey_pot:</code></td>
<td style="text-align:center">🍯</td>
<td style="text-align:center"><code>:apple:</code></td>
<td style="text-align:center">🍎</td>
</tr>
<tr>
<td style="text-align:center"><code>:green_apple:</code></td>
<td style="text-align:center">🍏</td>
<td style="text-align:center"><code>:tangerine:</code></td>
<td style="text-align:center">🍊</td>
<td style="text-align:center"><code>:lemon:</code></td>
<td style="text-align:center">🍋</td>
</tr>
<tr>
<td style="text-align:center"><code>:cherries:</code></td>
<td style="text-align:center">🍒</td>
<td style="text-align:center"><code>:grapes:</code></td>
<td style="text-align:center">🍇</td>
<td style="text-align:center"><code>:watermelon:</code></td>
<td style="text-align:center">🍉</td>
</tr>
<tr>
<td style="text-align:center"><code>:strawberry:</code></td>
<td style="text-align:center">🍓</td>
<td style="text-align:center"><code>:peach:</code></td>
<td style="text-align:center">🍑</td>
<td style="text-align:center"><code>:melon:</code></td>
<td style="text-align:center">🍈</td>
</tr>
<tr>
<td style="text-align:center"><code>:banana:</code></td>
<td style="text-align:center">🍌</td>
<td style="text-align:center"><code>:pear:</code></td>
<td style="text-align:center">🍐</td>
<td style="text-align:center"><code>:pineapple:</code></td>
<td style="text-align:center">🍍</td>
</tr>
<tr>
<td style="text-align:center"><code>:sweet_potato:</code></td>
<td style="text-align:center">🍠</td>
<td style="text-align:center"><code>:eggplant:</code></td>
<td style="text-align:center">🍆</td>
<td style="text-align:center"><code>:tomato:</code></td>
<td style="text-align:center">🍅</td>
</tr>
<tr>
<td style="text-align:center"><code>:corn:</code></td>
<td style="text-align:center">🌽</td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
</tr>
</tbody>
</table>
<h2 id="地点" tabindex="-1"><a class="header-anchor" href="#地点" aria-hidden="true">#</a> 地点</h2>
<table>
<thead>
<tr>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center"><code>:house:</code></td>
<td style="text-align:center">🏠</td>
<td style="text-align:center"><code>:house_with_garden:</code></td>
<td style="text-align:center">🏡</td>
<td style="text-align:center"><code>:school:</code></td>
<td style="text-align:center">🏫</td>
</tr>
<tr>
<td style="text-align:center"><code>:office:</code></td>
<td style="text-align:center">🏢</td>
<td style="text-align:center"><code>:post_office:</code></td>
<td style="text-align:center">🏣</td>
<td style="text-align:center"><code>:hospital:</code></td>
<td style="text-align:center">🏥</td>
</tr>
<tr>
<td style="text-align:center"><code>:bank:</code></td>
<td style="text-align:center">🏦</td>
<td style="text-align:center"><code>:convenience_store:</code></td>
<td style="text-align:center">🏪</td>
<td style="text-align:center"><code>:love_hotel:</code></td>
<td style="text-align:center">🏩</td>
</tr>
<tr>
<td style="text-align:center"><code>:hotel:</code></td>
<td style="text-align:center">🏨</td>
<td style="text-align:center"><code>:wedding:</code></td>
<td style="text-align:center">💒</td>
<td style="text-align:center"><code>:church:</code></td>
<td style="text-align:center">⛪</td>
</tr>
<tr>
<td style="text-align:center"><code>:department_store:</code></td>
<td style="text-align:center">🏬</td>
<td style="text-align:center"><code>:european_post_office:</code></td>
<td style="text-align:center">🏤</td>
<td style="text-align:center"><code>:city_sunrise:</code></td>
<td style="text-align:center">🌇</td>
</tr>
<tr>
<td style="text-align:center"><code>:city_sunset:</code></td>
<td style="text-align:center">🌆</td>
<td style="text-align:center"><code>:japanese_castle:</code></td>
<td style="text-align:center">🏯</td>
<td style="text-align:center"><code>:european_castle:</code></td>
<td style="text-align:center">🏰</td>
</tr>
<tr>
<td style="text-align:center"><code>:tent:</code></td>
<td style="text-align:center">⛺</td>
<td style="text-align:center"><code> :factory:</code></td>
<td style="text-align:center">🏭</td>
<td style="text-align:center"><code>:tokyo_tower:</code></td>
<td style="text-align:center">🗼</td>
</tr>
<tr>
<td style="text-align:center"><code>:japan:</code></td>
<td style="text-align:center">🗾</td>
<td style="text-align:center"><code>:mount_fuji:</code></td>
<td style="text-align:center">🗻</td>
<td style="text-align:center"><code>:sunrise_over_mountains:</code></td>
<td style="text-align:center">🌄</td>
</tr>
<tr>
<td style="text-align:center"><code>:sunrise:</code></td>
<td style="text-align:center">🌅</td>
<td style="text-align:center"><code>:stars:</code></td>
<td style="text-align:center">🌠</td>
<td style="text-align:center"><code>:statue_of_liberty:</code></td>
<td style="text-align:center">🗽</td>
</tr>
<tr>
<td style="text-align:center"><code>:bridge_at_night:</code></td>
<td style="text-align:center">🌉</td>
<td style="text-align:center"><code>:carousel_horse:</code></td>
<td style="text-align:center">🎠</td>
<td style="text-align:center"><code>:rainbow:</code></td>
<td style="text-align:center">🌈</td>
</tr>
<tr>
<td style="text-align:center"><code>:ferris_wheel:</code></td>
<td style="text-align:center">🎡</td>
<td style="text-align:center"><code>:fountain:</code></td>
<td style="text-align:center">⛲</td>
<td style="text-align:center"><code>:roller_coaster:</code></td>
<td style="text-align:center">🎢</td>
</tr>
<tr>
<td style="text-align:center"><code>:ship:</code></td>
<td style="text-align:center">🚢</td>
<td style="text-align:center"><code> :speedboat:</code></td>
<td style="text-align:center">🚤</td>
<td style="text-align:center"><code> :boat:</code></td>
<td style="text-align:center">⛵</td>
</tr>
<tr>
<td style="text-align:center"><code>:sailboat:</code></td>
<td style="text-align:center">⛵</td>
<td style="text-align:center"><code>:rowboat:</code></td>
<td style="text-align:center">🚣</td>
<td style="text-align:center"><code>:anchor:</code></td>
<td style="text-align:center">⚓</td>
</tr>
<tr>
<td style="text-align:center"><code>:rocket:</code></td>
<td style="text-align:center">🚀</td>
<td style="text-align:center"><code>:airplane:</code></td>
<td style="text-align:center">✈️</td>
<td style="text-align:center"><code>:helicopter:</code></td>
<td style="text-align:center">🚁</td>
</tr>
<tr>
<td style="text-align:center"><code>:steam_locomotive:</code></td>
<td style="text-align:center">🚂</td>
<td style="text-align:center"><code>:tram:</code></td>
<td style="text-align:center">🚊</td>
<td style="text-align:center"><code>:mountain_railway:</code></td>
<td style="text-align:center">🚞</td>
</tr>
<tr>
<td style="text-align:center"><code>:bike:</code></td>
<td style="text-align:center">🚲</td>
<td style="text-align:center"><code>:aerial_tramway:</code></td>
<td style="text-align:center">🚡</td>
<td style="text-align:center"><code>:suspension_railway:</code></td>
<td style="text-align:center">🚟</td>
</tr>
<tr>
<td style="text-align:center"><code>:mountain_cableway:</code></td>
<td style="text-align:center">🚠</td>
<td style="text-align:center"><code>:tractor:</code></td>
<td style="text-align:center">🚜</td>
<td style="text-align:center"><code>:blue_car:</code></td>
<td style="text-align:center">🚙</td>
</tr>
<tr>
<td style="text-align:center"><code>:oncoming_automobile:</code></td>
<td style="text-align:center">🚘</td>
<td style="text-align:center"><code>:car:</code></td>
<td style="text-align:center">🚗</td>
<td style="text-align:center"><code> :red_car:</code></td>
<td style="text-align:center">🚗</td>
</tr>
<tr>
<td style="text-align:center"><code>:taxi:</code></td>
<td style="text-align:center">🚕</td>
<td style="text-align:center"><code>:oncoming_taxi:</code></td>
<td style="text-align:center">🚖</td>
<td style="text-align:center"><code>:articulated_lorry:</code></td>
<td style="text-align:center">🚛</td>
</tr>
<tr>
<td style="text-align:center"><code>:bus:</code></td>
<td style="text-align:center">🚌</td>
<td style="text-align:center"><code>:oncoming_bus:</code></td>
<td style="text-align:center">🚍</td>
<td style="text-align:center"><code>:rotating_light:</code></td>
<td style="text-align:center">🚨</td>
</tr>
<tr>
<td style="text-align:center"><code>:police_car:</code></td>
<td style="text-align:center">🚓</td>
<td style="text-align:center"><code>:oncoming_police_car:</code></td>
<td style="text-align:center">🚔</td>
<td style="text-align:center"><code>:fire_engine:</code></td>
<td style="text-align:center">🚒</td>
</tr>
<tr>
<td style="text-align:center"><code>:ambulance:</code></td>
<td style="text-align:center">🚑</td>
<td style="text-align:center"><code>:minibus:</code></td>
<td style="text-align:center">🚐</td>
<td style="text-align:center"><code> :truck:</code></td>
<td style="text-align:center">🚚</td>
</tr>
<tr>
<td style="text-align:center"><code> :train:</code></td>
<td style="text-align:center">🚋</td>
<td style="text-align:center"><code> :station:</code></td>
<td style="text-align:center">🚉</td>
<td style="text-align:center"><code> :train2:</code></td>
<td style="text-align:center">🚆</td>
</tr>
<tr>
<td style="text-align:center"><code>:bullettrain_front:</code></td>
<td style="text-align:center">🚅</td>
<td style="text-align:center"><code> :bullettrain_side:</code></td>
<td style="text-align:center">🚄</td>
<td style="text-align:center"><code> :light_rail:</code></td>
<td style="text-align:center">🚈</td>
</tr>
<tr>
<td style="text-align:center"><code> :monorail:</code></td>
<td style="text-align:center">🚝</td>
<td style="text-align:center"><code> :railway_car:</code></td>
<td style="text-align:center">🚃</td>
<td style="text-align:center"><code> :trolleybus:</code></td>
<td style="text-align:center">🚎</td>
</tr>
<tr>
<td style="text-align:center"><code>:ticket:</code></td>
<td style="text-align:center">🎫</td>
<td style="text-align:center"><code> :fuelpump:</code></td>
<td style="text-align:center">⛽</td>
<td style="text-align:center"><code> :vertical_traffic_light:</code></td>
<td style="text-align:center">🚦</td>
</tr>
<tr>
<td style="text-align:center"><code> :traffic_light:</code></td>
<td style="text-align:center">🚥</td>
<td style="text-align:center"><code> :warning:</code></td>
<td style="text-align:center">⚠️</td>
<td style="text-align:center"><code> :construction:</code></td>
<td style="text-align:center">🚧</td>
</tr>
<tr>
<td style="text-align:center"><code>:beginner:</code></td>
<td style="text-align:center">🔰</td>
<td style="text-align:center"><code> :atm:</code></td>
<td style="text-align:center">🏧</td>
<td style="text-align:center"><code> :slot_machine:</code></td>
<td style="text-align:center">🎰</td>
</tr>
<tr>
<td style="text-align:center"><code> :busstop:</code></td>
<td style="text-align:center">🚏</td>
<td style="text-align:center"><code> :barber:</code></td>
<td style="text-align:center">💈</td>
<td style="text-align:center"><code> :hotsprings:</code></td>
<td style="text-align:center">♨️</td>
</tr>
<tr>
<td style="text-align:center"><code> :checkered_flag:</code></td>
<td style="text-align:center">🏁</td>
<td style="text-align:center"><code> :crossed_flags:</code></td>
<td style="text-align:center">🎌</td>
<td style="text-align:center"><code> :izakaya_lantern:</code></td>
<td style="text-align:center">🏮</td>
</tr>
<tr>
<td style="text-align:center"><code>:moyai:</code></td>
<td style="text-align:center">🗿</td>
<td style="text-align:center"><code> :circus_tent:</code></td>
<td style="text-align:center">🎪</td>
<td style="text-align:center"><code> :performing_arts:</code></td>
<td style="text-align:center">🎭</td>
</tr>
<tr>
<td style="text-align:center"><code> :round_pushpin:</code></td>
<td style="text-align:center">📍</td>
<td style="text-align:center"><code> :triangular_flag_on_post:</code></td>
<td style="text-align:center">🚩</td>
<td style="text-align:center"><code> :jp:</code></td>
<td style="text-align:center">🇯🇵</td>
</tr>
<tr>
<td style="text-align:center"><code>:kr:</code></td>
<td style="text-align:center">🇰🇷</td>
<td style="text-align:center"><code> :cn:</code></td>
<td style="text-align:center">🇨🇳</td>
<td style="text-align:center"><code> :us:</code></td>
<td style="text-align:center">🇺🇸</td>
</tr>
<tr>
<td style="text-align:center"><code> :fr:</code></td>
<td style="text-align:center">🇫🇷</td>
<td style="text-align:center"><code>:es:</code></td>
<td style="text-align:center">🇪🇸</td>
<td style="text-align:center"><code> :it:</code></td>
<td style="text-align:center">🇮🇹</td>
</tr>
<tr>
<td style="text-align:center"><code>:ru:</code></td>
<td style="text-align:center">🇷🇺</td>
<td style="text-align:center"><code> :gb:</code></td>
<td style="text-align:center">🇬🇧</td>
<td style="text-align:center"><code> :uk:</code></td>
<td style="text-align:center">🇬🇧</td>
</tr>
<tr>
<td style="text-align:center"><code>:de:</code></td>
<td style="text-align:center">🇩🇪</td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
</tr>
</tbody>
</table>
<h2 id="符号" tabindex="-1"><a class="header-anchor" href="#符号" aria-hidden="true">#</a> 符号</h2>
<table>
<thead>
<tr>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
<th style="text-align:center">syntax</th>
<th style="text-align:center">preview</th>
</tr>
</thead>
<tbody>
<tr>
<td style="text-align:center"><code>:one:</code></td>
<td style="text-align:center">1️⃣</td>
<td style="text-align:center"><code>:two:</code></td>
<td style="text-align:center">2️⃣</td>
<td style="text-align:center"><code>:three:</code></td>
<td style="text-align:center">3️⃣</td>
</tr>
<tr>
<td style="text-align:center"><code>:four:</code></td>
<td style="text-align:center">4️⃣</td>
<td style="text-align:center"><code>:five:</code></td>
<td style="text-align:center">5️⃣</td>
<td style="text-align:center"><code> :six:</code></td>
<td style="text-align:center">6️⃣</td>
</tr>
<tr>
<td style="text-align:center"><code> :seven:</code></td>
<td style="text-align:center">7️⃣</td>
<td style="text-align:center"><code> :eight:</code></td>
<td style="text-align:center">8️⃣</td>
<td style="text-align:center"><code> :nine:</code></td>
<td style="text-align:center">9️⃣</td>
</tr>
<tr>
<td style="text-align:center"><code> :keycap_ten:</code></td>
<td style="text-align:center">🔟</td>
<td style="text-align:center"><code> :1234:</code></td>
<td style="text-align:center">🔢</td>
<td style="text-align:center"><code> :zero:</code></td>
<td style="text-align:center">0️⃣</td>
</tr>
<tr>
<td style="text-align:center"><code>:hash:</code></td>
<td style="text-align:center">#️⃣</td>
<td style="text-align:center"><code> :symbols:</code></td>
<td style="text-align:center">🔣</td>
<td style="text-align:center"><code> :arrow_backward:</code></td>
<td style="text-align:center">◀️</td>
</tr>
<tr>
<td style="text-align:center"><code> :arrow_down:</code></td>
<td style="text-align:center">⬇️</td>
<td style="text-align:center"><code> :arrow_forward:</code></td>
<td style="text-align:center">▶️</td>
<td style="text-align:center"><code> :arrow_left:</code></td>
<td style="text-align:center">⬅️</td>
</tr>
<tr>
<td style="text-align:center"><code> :capital_abcd:</code></td>
<td style="text-align:center">🔠</td>
<td style="text-align:center"><code> :abcd:</code></td>
<td style="text-align:center">🔡</td>
<td style="text-align:center"><code> :abc:</code></td>
<td style="text-align:center">🔤</td>
</tr>
<tr>
<td style="text-align:center"><code>:arrow_lower_left:</code></td>
<td style="text-align:center">↙️</td>
<td style="text-align:center"><code> :arrow_lower_right:</code></td>
<td style="text-align:center">↘️</td>
<td style="text-align:center"><code> :arrow_right:</code></td>
<td style="text-align:center">➡️</td>
</tr>
<tr>
<td style="text-align:center"><code> :arrow_up:</code></td>
<td style="text-align:center">⬆️</td>
<td style="text-align:center"><code> :arrow_upper_left:</code></td>
<td style="text-align:center">↖️</td>
<td style="text-align:center"><code> :arrow_upper_right:</code></td>
<td style="text-align:center">↗️</td>
</tr>
<tr>
<td style="text-align:center"><code>:arrow_double_down:</code></td>
<td style="text-align:center">⏬</td>
<td style="text-align:center"><code> :arrow_double_up:</code></td>
<td style="text-align:center">⏫</td>
<td style="text-align:center"><code> :arrow_down_small:</code></td>
<td style="text-align:center">🔽</td>
</tr>
<tr>
<td style="text-align:center"><code> :arrow_heading_down:</code></td>
<td style="text-align:center">⤵️</td>
<td style="text-align:center"><code> :arrow_heading_up:</code></td>
<td style="text-align:center">⤴️</td>
<td style="text-align:center"><code> :leftwards_arrow_with_hook:</code></td>
<td style="text-align:center">↩️</td>
</tr>
<tr>
<td style="text-align:center"><code>:arrow_right_hook:</code></td>
<td style="text-align:center">↪️</td>
<td style="text-align:center"><code> :left_right_arrow:</code></td>
<td style="text-align:center">↔️</td>
<td style="text-align:center"><code> :arrow_up_down:</code></td>
<td style="text-align:center">↕️</td>
</tr>
<tr>
<td style="text-align:center"><code> :arrow_up_small:</code></td>
<td style="text-align:center">🔼</td>
<td style="text-align:center"><code> :arrows_clockwise:</code></td>
<td style="text-align:center">🔃</td>
<td style="text-align:center"><code> :arrows_counterclockwise:</code></td>
<td style="text-align:center">🔄</td>
</tr>
<tr>
<td style="text-align:center"><code> :rewind:</code></td>
<td style="text-align:center">⏪</td>
<td style="text-align:center"><code> :fast_forward:</code></td>
<td style="text-align:center">⏩</td>
<td style="text-align:center"><code> :information_source:</code></td>
<td style="text-align:center">ℹ️</td>
</tr>
<tr>
<td style="text-align:center"><code>:ok:</code></td>
<td style="text-align:center">🆗</td>
<td style="text-align:center"><code> :twisted_rightwards_arrows:</code></td>
<td style="text-align:center">🔀</td>
<td style="text-align:center"><code> :repeat:</code></td>
<td style="text-align:center">🔁</td>
</tr>
<tr>
<td style="text-align:center"><code> :repeat_one:</code></td>
<td style="text-align:center">🔂</td>
<td style="text-align:center"><code> :new:</code></td>
<td style="text-align:center">🆕</td>
<td style="text-align:center"><code> :top:</code></td>
<td style="text-align:center">🔝</td>
</tr>
<tr>
<td style="text-align:center"><code>:up:</code></td>
<td style="text-align:center">🆙</td>
<td style="text-align:center"><code>:cool:</code></td>
<td style="text-align:center">🆒</td>
<td style="text-align:center"><code> :free:</code></td>
<td style="text-align:center">🆓</td>
</tr>
<tr>
<td style="text-align:center"><code>:ng:</code></td>
<td style="text-align:center">🆖</td>
<td style="text-align:center"><code>:cinema:</code></td>
<td style="text-align:center">🎦</td>
<td style="text-align:center"><code> :koko:</code></td>
<td style="text-align:center">🈁</td>
</tr>
<tr>
<td style="text-align:center"><code> :signal_strength:</code></td>
<td style="text-align:center">📶</td>
<td style="text-align:center"><code> :u5272:</code></td>
<td style="text-align:center">:u5272:</td>
<td style="text-align:center"><code> :u5408:</code></td>
<td style="text-align:center">:u5408:</td>
</tr>
<tr>
<td style="text-align:center"><code> :u55b6:</code></td>
<td style="text-align:center">:u55b6:</td>
<td style="text-align:center"><code> :u6307:</code></td>
<td style="text-align:center">:u6307:</td>
<td style="text-align:center"><code> :u6708:</code></td>
<td style="text-align:center">:u6708:</td>
</tr>
<tr>
<td style="text-align:center"><code> :u6709:</code></td>
<td style="text-align:center">:u6709:</td>
<td style="text-align:center"><code> :u6e80:</code></td>
<td style="text-align:center">🈵</td>
<td style="text-align:center"><code> :u7121:</code></td>
<td style="text-align:center">:u7121:</td>
</tr>
<tr>
<td style="text-align:center"><code> :u7533:</code></td>
<td style="text-align:center">:u7533:</td>
<td style="text-align:center"><code> :u7a7a:</code></td>
<td style="text-align:center">:u7a7a:</td>
<td style="text-align:center"><code> :u7981:</code></td>
<td style="text-align:center">:u7981:</td>
</tr>
<tr>
<td style="text-align:center"><code>:sa:</code></td>
<td style="text-align:center">🈂️</td>
<td style="text-align:center"><code> :restroom:</code></td>
<td style="text-align:center">🚻</td>
<td style="text-align:center"><code> :mens:</code></td>
<td style="text-align:center">🚹</td>
</tr>
<tr>
<td style="text-align:center"><code> :womens:</code></td>
<td style="text-align:center">🚺</td>
<td style="text-align:center"><code> :baby_symbol:</code></td>
<td style="text-align:center">🚼</td>
<td style="text-align:center"><code> :no_smoking:</code></td>
<td style="text-align:center">🚭</td>
</tr>
<tr>
<td style="text-align:center"><code>:parking:</code></td>
<td style="text-align:center">🅿️</td>
<td style="text-align:center"><code> :wheelchair:</code></td>
<td style="text-align:center">♿</td>
<td style="text-align:center"><code> :metro:</code></td>
<td style="text-align:center">🚇</td>
</tr>
<tr>
<td style="text-align:center"><code> :baggage_claim:</code></td>
<td style="text-align:center">🛄</td>
<td style="text-align:center"><code> :accept:</code></td>
<td style="text-align:center">🉑</td>
<td style="text-align:center"><code> :wc:</code></td>
<td style="text-align:center">🚾</td>
</tr>
<tr>
<td style="text-align:center"><code>:potable_water:</code></td>
<td style="text-align:center">🚰</td>
<td style="text-align:center"><code> :put_litter_in_its_place:</code></td>
<td style="text-align:center">🚮</td>
<td style="text-align:center"><code> :secret:</code></td>
<td style="text-align:center">㊙️</td>
</tr>
<tr>
<td style="text-align:center"><code> :congratulations:</code></td>
<td style="text-align:center">㊗️</td>
<td style="text-align:center"><code> :m:</code></td>
<td style="text-align:center">Ⓜ️</td>
<td style="text-align:center"><code> :passport_control:</code></td>
<td style="text-align:center">🛂</td>
</tr>
<tr>
<td style="text-align:center"><code>:left_luggage:</code></td>
<td style="text-align:center">🛅</td>
<td style="text-align:center"><code> :customs:</code></td>
<td style="text-align:center">🛃</td>
<td style="text-align:center"><code> :ideograph_advantage:</code></td>
<td style="text-align:center">🉐</td>
</tr>
<tr>
<td style="text-align:center"><code> :cl:</code></td>
<td style="text-align:center">🆑</td>
<td style="text-align:center"><code> :sos:</code></td>
<td style="text-align:center">🆘</td>
<td style="text-align:center"><code> :id:</code></td>
<td style="text-align:center">🆔</td>
</tr>
<tr>
<td style="text-align:center"><code> :no_entry_sign:</code></td>
<td style="text-align:center">🚫</td>
<td style="text-align:center"><code> :underage:</code></td>
<td style="text-align:center">🔞</td>
<td style="text-align:center"><code> :no_mobile_phones:</code></td>
<td style="text-align:center">📵</td>
</tr>
<tr>
<td style="text-align:center"><code> :do_not_litter:</code></td>
<td style="text-align:center">🚯</td>
<td style="text-align:center"><code> :non-potable_water:</code></td>
<td style="text-align:center">🚱</td>
<td style="text-align:center"><code> :no_bicycles:</code></td>
<td style="text-align:center">🚳</td>
</tr>
<tr>
<td style="text-align:center"><code>:no_pedestrians:</code></td>
<td style="text-align:center">🚷</td>
<td style="text-align:center"><code> :children_crossing:</code></td>
<td style="text-align:center">🚸</td>
<td style="text-align:center"><code> :no_entry:</code></td>
<td style="text-align:center">⛔</td>
</tr>
<tr>
<td style="text-align:center"><code> :eight_spoked_asterisk:</code></td>
<td style="text-align:center">✳️</td>
<td style="text-align:center"><code> :eight_pointed_black_star:</code></td>
<td style="text-align:center">✴️</td>
<td style="text-align:center"><code> :heart_decoration:</code></td>
<td style="text-align:center">💟</td>
</tr>
<tr>
<td style="text-align:center"><code> :vs:</code></td>
<td style="text-align:center">🆚</td>
<td style="text-align:center"><code> :vibration_mode:</code></td>
<td style="text-align:center">📳</td>
<td style="text-align:center"><code> :mobile_phone_off:</code></td>
<td style="text-align:center">📴</td>
</tr>
<tr>
<td style="text-align:center"><code> :chart:</code></td>
<td style="text-align:center">💹</td>
<td style="text-align:center"><code> :currency_exchange:</code></td>
<td style="text-align:center">💱</td>
<td style="text-align:center"><code> :aries:</code></td>
<td style="text-align:center">♈</td>
</tr>
<tr>
<td style="text-align:center"><code> :taurus:</code></td>
<td style="text-align:center">♉</td>
<td style="text-align:center"><code>:gemini:</code></td>
<td style="text-align:center">♊</td>
<td style="text-align:center"><code> :cancer:</code></td>
<td style="text-align:center">♋</td>
</tr>
<tr>
<td style="text-align:center"><code>:leo:</code></td>
<td style="text-align:center">♌</td>
<td style="text-align:center"><code> :virgo:</code></td>
<td style="text-align:center">♍</td>
<td style="text-align:center"><code> :libra:</code></td>
<td style="text-align:center">♎</td>
</tr>
<tr>
<td style="text-align:center"><code> :scorpius:</code></td>
<td style="text-align:center">♏</td>
<td style="text-align:center"><code> :sagittarius:</code></td>
<td style="text-align:center">♐</td>
<td style="text-align:center"><code> :capricorn:</code></td>
<td style="text-align:center">♑</td>
</tr>
<tr>
<td style="text-align:center"><code> :aquarius:</code></td>
<td style="text-align:center">♒</td>
<td style="text-align:center"><code> :pisces:</code></td>
<td style="text-align:center">♓</td>
<td style="text-align:center"><code> :ophiuchus:</code></td>
<td style="text-align:center">⛎</td>
</tr>
<tr>
<td style="text-align:center"><code> :six_pointed_star:</code></td>
<td style="text-align:center">🔯</td>
<td style="text-align:center"><code> :negative_squared_cross_mark:</code></td>
<td style="text-align:center">❎</td>
<td style="text-align:center"><code> :a:</code></td>
<td style="text-align:center">🅰️</td>
</tr>
<tr>
<td style="text-align:center"><code>:b:</code></td>
<td style="text-align:center">🅱️</td>
<td style="text-align:center"><code> :ab:</code></td>
<td style="text-align:center">🆎</td>
<td style="text-align:center"><code> :o2:</code></td>
<td style="text-align:center">🅾️</td>
</tr>
<tr>
<td style="text-align:center"><code> :diamond_shape_with_a_dot_inside:</code></td>
<td style="text-align:center">💠</td>
<td style="text-align:center"><code> :recycle:</code></td>
<td style="text-align:center">♻️</td>
<td style="text-align:center"><code> :end:</code></td>
<td style="text-align:center">🔚</td>
</tr>
<tr>
<td style="text-align:center"><code> :on:</code></td>
<td style="text-align:center">🔛</td>
<td style="text-align:center"><code> :soon:</code></td>
<td style="text-align:center">🔜</td>
<td style="text-align:center"><code> :clock1:</code></td>
<td style="text-align:center">🕐</td>
</tr>
<tr>
<td style="text-align:center"><code>:clock130:</code></td>
<td style="text-align:center">🕜</td>
<td style="text-align:center"><code> :clock10:</code></td>
<td style="text-align:center">🕙</td>
<td style="text-align:center"><code> :clock1030:</code></td>
<td style="text-align:center">🕥</td>
</tr>
<tr>
<td style="text-align:center"><code> :clock11:</code></td>
<td style="text-align:center">🕚</td>
<td style="text-align:center"><code> :clock1130:</code></td>
<td style="text-align:center">🕦</td>
<td style="text-align:center"><code> :clock12:</code></td>
<td style="text-align:center">🕛</td>
</tr>
<tr>
<td style="text-align:center"><code> :clock1230:</code></td>
<td style="text-align:center">🕧</td>
<td style="text-align:center"><code> :clock2:</code></td>
<td style="text-align:center">🕑</td>
<td style="text-align:center"><code>:clock230:</code></td>
<td style="text-align:center">🕝</td>
</tr>
<tr>
<td style="text-align:center"><code> :clock3:</code></td>
<td style="text-align:center">🕒</td>
<td style="text-align:center"><code> :clock330:</code></td>
<td style="text-align:center">🕞</td>
<td style="text-align:center"><code> :clock4:</code></td>
<td style="text-align:center">🕓</td>
</tr>
<tr>
<td style="text-align:center"><code>:clock430:</code></td>
<td style="text-align:center">🕟</td>
<td style="text-align:center"><code> :clock5:</code></td>
<td style="text-align:center">🕔</td>
<td style="text-align:center"><code> :clock530:</code></td>
<td style="text-align:center">🕠</td>
</tr>
<tr>
<td style="text-align:center"><code>:clock6:</code></td>
<td style="text-align:center">🕕</td>
<td style="text-align:center"><code> :clock630:</code></td>
<td style="text-align:center">🕡</td>
<td style="text-align:center"><code> :clock7:</code></td>
<td style="text-align:center">🕖</td>
</tr>
<tr>
<td style="text-align:center"><code>:clock730:</code></td>
<td style="text-align:center">🕢</td>
<td style="text-align:center"><code> :clock8:</code></td>
<td style="text-align:center">🕗</td>
<td style="text-align:center"><code> :clock830:</code></td>
<td style="text-align:center">🕣</td>
</tr>
<tr>
<td style="text-align:center"><code> :clock9:</code></td>
<td style="text-align:center">🕘</td>
<td style="text-align:center"><code>:clock930:</code></td>
<td style="text-align:center">🕤</td>
<td style="text-align:center"><code> :heavy_dollar_sign:</code></td>
<td style="text-align:center">💲</td>
</tr>
<tr>
<td style="text-align:center"><code> :copyright:</code></td>
<td style="text-align:center">©️</td>
<td style="text-align:center"><code> :registered:</code></td>
<td style="text-align:center">®️</td>
<td style="text-align:center"><code> :tm:</code></td>
<td style="text-align:center">™️</td>
</tr>
<tr>
<td style="text-align:center"><code>:x:</code></td>
<td style="text-align:center">❌</td>
<td style="text-align:center"><code>:heavy_exclamation_mark:</code></td>
<td style="text-align:center">❗</td>
<td style="text-align:center"><code>:bangbang:</code></td>
<td style="text-align:center">‼️</td>
</tr>
<tr>
<td style="text-align:center"><code>:interrobang:</code></td>
<td style="text-align:center">⁉️</td>
<td style="text-align:center"><code> :o:</code></td>
<td style="text-align:center">⭕</td>
<td style="text-align:center"><code> :heavy_multiplication_x:</code></td>
<td style="text-align:center">✖️</td>
</tr>
<tr>
<td style="text-align:center"><code> :heavy_plus_sign:</code></td>
<td style="text-align:center">➕</td>
<td style="text-align:center"><code> :heavy_minus_sign:</code></td>
<td style="text-align:center">➖</td>
<td style="text-align:center"><code>:heavy_division_sign:</code></td>
<td style="text-align:center">➗</td>
</tr>
<tr>
<td style="text-align:center"><code> :white_flower:</code></td>
<td style="text-align:center">💮</td>
<td style="text-align:center"><code> :100:</code></td>
<td style="text-align:center">💯</td>
<td style="text-align:center"><code>:heavy_check_mark:</code></td>
<td style="text-align:center">✔️</td>
</tr>
<tr>
<td style="text-align:center"><code>:ballot_box_with_check:</code></td>
<td style="text-align:center">☑️</td>
<td style="text-align:center"><code> :radio_button:</code></td>
<td style="text-align:center">🔘</td>
<td style="text-align:center"><code> :link:</code></td>
<td style="text-align:center">🔗</td>
</tr>
<tr>
<td style="text-align:center"><code>:curly_loop:</code></td>
<td style="text-align:center">➰</td>
<td style="text-align:center"><code> :wavy_dash:</code></td>
<td style="text-align:center">〰️</td>
<td style="text-align:center"><code> :part_alternation_mark:</code></td>
<td style="text-align:center">〽️</td>
</tr>
<tr>
<td style="text-align:center"><code>:trident:</code></td>
<td style="text-align:center">🔱</td>
<td style="text-align:center"><code>:black_large_square:</code></td>
<td style="text-align:center">⬛</td>
<td style="text-align:center"><code> :white_large_square:</code></td>
<td style="text-align:center">⬜</td>
</tr>
<tr>
<td style="text-align:center"><code>:white_check_mark:</code></td>
<td style="text-align:center">✅</td>
<td style="text-align:center"><code> :white_square_button:</code></td>
<td style="text-align:center">🔳</td>
<td style="text-align:center"><code> :black_square_button:</code></td>
<td style="text-align:center">🔲</td>
</tr>
<tr>
<td style="text-align:center"><code> :black_circle:</code></td>
<td style="text-align:center">⚫</td>
<td style="text-align:center"><code> :white_circle:</code></td>
<td style="text-align:center">⚪</td>
<td style="text-align:center"><code> :red_circle:</code></td>
<td style="text-align:center">🔴</td>
</tr>
<tr>
<td style="text-align:center"><code> :large_blue_circle:</code></td>
<td style="text-align:center">🔵</td>
<td style="text-align:center"><code> :large_blue_diamond:</code></td>
<td style="text-align:center">🔷</td>
<td style="text-align:center"><code> :large_orange_diamond:</code></td>
<td style="text-align:center">🔶</td>
</tr>
<tr>
<td style="text-align:center"><code> :small_blue_diamond:</code></td>
<td style="text-align:center">🔹</td>
<td style="text-align:center"><code> :small_orange_diamond:</code></td>
<td style="text-align:center">🔸</td>
<td style="text-align:center"><code> :small_red_triangle:</code></td>
<td style="text-align:center">🔺</td>
</tr>
<tr>
<td style="text-align:center"><code>:small_red_triangle_down:</code></td>
<td style="text-align:center">🔻</td>
<td style="text-align:center"><code> :shipit:</code></td>
<td style="text-align:center">:shipit:</td>
<td style="text-align:center"></td>
<td style="text-align:center"></td>
</tr>
</tbody>
</table>
</template>
