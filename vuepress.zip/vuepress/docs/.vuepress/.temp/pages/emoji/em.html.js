export const data = {
  "key": "v-2f7343e2",
  "path": "/emoji/em.html",
  "title": "em",
  "lang": "en-US",
  "frontmatter": {},
  "excerpt": "",
  "headers": [],
  "git": {},
  "filePathRelative": "emoji/em.md"
}
