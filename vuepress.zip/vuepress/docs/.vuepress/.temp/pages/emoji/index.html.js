export const data = {
  "key": "v-7c2a9ce2",
  "path": "/emoji/",
  "title": "emoji表情",
  "lang": "en-US",
  "frontmatter": {
    "title": "emoji表情",
    "date": "2022-01-07T00:00:00.000Z"
  },
  "excerpt": "",
  "headers": [
    {
      "level": 2,
      "title": "人物",
      "slug": "人物",
      "children": []
    },
    {
      "level": 2,
      "title": "自然",
      "slug": "自然",
      "children": []
    },
    {
      "level": 2,
      "title": "物体",
      "slug": "物体",
      "children": []
    },
    {
      "level": 2,
      "title": "地点",
      "slug": "地点",
      "children": []
    },
    {
      "level": 2,
      "title": "符号",
      "slug": "符号",
      "children": []
    }
  ],
  "git": {},
  "filePathRelative": "emoji/README.md"
}
